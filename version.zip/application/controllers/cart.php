<?php

class Cart extends Front_Controller {
	
	

	function index()
	{
		
		$categories = $this->Category_model->get_categoryy();
		$result = array();
		foreach($categories as $cat){
    	if($cat['parent_id'] && array_key_exists($cat['parent_id'], $result)){
        $result[$cat['parent_id']]['sub_categories'][] = $cat;
    	}
    	else
		{
        $result[$cat['id']] = $cat;   		 
		}
		}
		$data['query'] 			= 'Search from over 500+ products';		
		$data['result']			= $result;
		
		//print_r($data);
		$data['middle_content'] = 'frontend/home';
		$this->load->view('templates/template',$data);
		
	}

	function page($id = false)
	{
		//if there is no page id provided redirect to the homepage.
		$data['page']	= $this->Page_model->get_page($id);
		if(!$data['page'])
		{
			show_404();
		}
		$this->load->model('Page_model');
		$this->load->model('Settings_model');
		$data['base_url']			= $this->uri->segment_array();
		
		$data['fb_like']			= true;

		$data['page_title']			= $data['page']->title;
		
		$data['meta']				= $data['page']->meta;
		$data['seo_title']			= (!empty($data['page']->seo_title))?$data['page']->seo_title:$data['page']->title;
		
		$data['gift_cards_enabled'] = $this->gift_cards_enabled;
		$data['query'] 			= 'Search from over 500+ products';	
		$this->view('page', $data);
	}
	
	function about_us()
	{
		$data['query'] 			= 'Search from over 500+ products';	
		$data['middle_content'] = 'frontend/aboutus';					
		$this->load->view('templates/subtemplate', $data);
	}
	function why_us()
	{
		$data['query'] 			= 'Search from over 500+ products';	
		$data['middle_content'] = 'frontend/why_us';					
		$this->load->view('templates/subtemplate', $data);
	}
	function contact_us()
	{
		$data['middle_content'] = 'frontend/contactus';					
		$this->load->view('templates/subtemplate', $data);
	}
	
	function privacy_policy()
	{
		$data['middle_content'] = 'frontend/privacypolicy';					
		$this->load->view('templates/subtemplate', $data);
	}
	
	function terms_conditions()
	{
		$data['middle_content'] = 'frontend/terms';					
		$this->load->view('templates/subtemplate', $data);
	}
	function feedback()
	{
		$data['middle_content'] = 'frontend/feedback';					
		$this->load->view('templates/subtemplate', $data);
	}
	
	function search($code=false, $page = 0)
	{
		$this->load->model('Search_model');
		
		//check to see if we have a search term
		if(!$code)
		{
			//if the term is in post, save it to the db and give me a reference
			$term		= $this->input->post('term', true);
			$code		= $this->Search_model->record_term($term);
			
			// no code? redirect so we can have the code in place for the sorting.
			// I know this isn't the best way...
			redirect('cart/search/'.$code.'/'.$page);
		}
		else
		{
			//if we have the md5 string, get the term
			$term	= $this->Search_model->get_term($code);
		}
		
		if(empty($term))
		{
			//if there is still no search term throw an error
			$this->session->set_flashdata('error', lang('search_error'));
			redirect('cart');
		}

		$data['page_title']			= lang('search');
		
		//fix for the category view page.
		$data['base_url']			= array();
		
		$sort_array = array(
							'name/asc' => array('by' => 'name', 'sort'=>'ASC'),
							'name/desc' => array('by' => 'name', 'sort'=>'DESC'),
							'price/asc' => array('by' => 'sort_price', 'sort'=>'ASC'),
							'price/desc' => array('by' => 'sort_price', 'sort'=>'DESC'),
							);
		$sort_by	= array('by'=>false, 'sort'=>false);
	
		if(isset($_GET['by']))
		{
			if(isset($sort_array[$_GET['by']]))
			{
				$sort_by	= $sort_array[$_GET['by']];
			}
		}
		
			$data['page_title']	= lang('search');
			
			$config['per_page']		= 50;
			
			
			
			$result					= $this->Product_model->search_products($term, $config['per_page'], $page, $sort_by['by'], $sort_by['sort']);
			
	
			$data['products']		= $result['products'];
			foreach ($data['products'] as &$p)
			{
				$p->images	= (array)json_decode($p->images);
				$p->options	= $this->Option_model->get_product_options($p->id);
			}
			
			$this->view('category', $data);
	}
	

	function search_products($query = false)
	{	
		if($query)
		{
		$search_query		= $query;
		$categories = $this->Category_model->get_categoryy();
		$result = array();
		foreach($categories as $cat){
    	if($cat['parent_id'] && array_key_exists($cat['parent_id'], $result)){
        $result[$cat['parent_id']]['sub_categories'][] = $cat;
    	}
    	else
		{
        $result[$cat['id']] = $cat;   		 
		}
		}
				
		$data['related_category']			= $result;
		
		$base_url	= $this->uri->segment_array();
				
		$data['base_url']	= $base_url;
		$base_url			= implode('/', $base_url);
		
		
		$data['products']	= $this->Product_model->auto_search($search_query);
		foreach ($data['products'] as &$p)
			{
				$p->images	= (array)json_decode($p->images);
				$p->options	= $this->Option_model->get_product_options($p->id);
			}
		
		$data['query'] 			= $query;	
		$data['middle_content'] = 'frontend/search_products';
					
		$this->load->view('templates/template',$data);		
		}
		else
		{
			$categories = $this->Category_model->get_categoryy();
			$result = array();
			foreach($categories as $cat){
			if($cat['parent_id'] && array_key_exists($cat['parent_id'], $result)){
			$result[$cat['parent_id']]['sub_categories'][] = $cat;
			}
			else
			{
			$result[$cat['id']] = $cat;   		 
			}
			}
			$data['query'] 			= 'Search from over 500+ products';		
			$data['result']			= $result;
			
			//print_r($data);
			$data['middle_content'] = 'frontend/home';
			$this->load->view('templates/template',$data);
		}
	}

	
	function category($id)
	{	
		//get the category
		$data['category'] = $this->Category_model->get_category($id);
				
		if (!$data['category'] || $data['category']->enabled==0)
		{
			show_404();
		}
		
		$categories = $this->Category_model->get_categoryy();
		$result = array();
		foreach($categories as $cat){
    	if($cat['parent_id'] && array_key_exists($cat['parent_id'], $result)){
        $result[$cat['parent_id']]['sub_categories'][] = $cat;
    	}
    	else
		{
        $result[$cat['id']] = $cat;   		 
		}
		}
				
		$data['related_category']			= $result;
		
		$product_count = $this->Product_model->count_products($data['category']->id);
		
		//set up pagination
		$segments	= $this->uri->total_segments();
		$base_url	= $this->uri->segment_array();
		
		if($data['category']->slug == $base_url[count($base_url)])
		{
			$page	= 0;
			$segments++;
		}
		else
		{
			$page	= array_splice($base_url, -1, 1);
			$page	= $page[0];
		}
		
		$data['base_url']	= $base_url;
		$base_url			= implode('/', $base_url);
		
		$data['meta']		= $data['category']->meta;
		$data['seo_title']	= (!empty($data['category']->seo_title))?$data['category']->seo_title:$data['category']->name;
		$data['page_title']	= $data['category']->name;
		
		$sort_array = array(
							'name/asc' => array('by' => 'products.name', 'sort'=>'ASC'),
							'name/desc' => array('by' => 'products.name', 'sort'=>'DESC'),
							'price/asc' => array('by' => 'sort_price', 'sort'=>'ASC'),
							'price/desc' => array('by' => 'sort_price', 'sort'=>'DESC'),
							);
		$sort_by	= array('by'=>'sequence', 'sort'=>'ASC');
	
		if(isset($_GET['by']))
		{
			if(isset($sort_array[$_GET['by']]))
			{
				$sort_by	= $sort_array[$_GET['by']];
			}
		}
	    
		$config['per_page']	  = 100;
		
		$data['products']	= $this->Product_model->get_products($data['category']->id, $config['per_page'], $page, $sort_by['by'], $sort_by['sort']);
		
		foreach ($data['products'] as &$p)
			{
				$p->images	= (array)json_decode($p->images);
				$p->options	= $this->Option_model->get_product_options($p->id);
			}
		
		$data['query'] 			= 'Search from over 500+ products';	
		$data['middle_content'] = 'frontend/products';
					
		$this->load->view('templates/template',$data);
	}
	
	function product()
	{
		//get the product
		$id		    		= $this->input->post('id');
		$data['product']	= $this->Product_model->get_product($id);		
		$data['base_url']	= $this->uri->segment_array();			
		if($data['product']->images == 'false')
		{
			$data['product']->images = array();
		}
		else
		{
			$data['product']->images	= array_values((array)json_decode($data['product']->images));
		}
		$data['middle_content'] = 'frontend/product_details_model_pop_up';
					
		echo $this->load->view('frontend/product_details_model_pop_up',$data);		
	}
	
	
	function more_product()
	{
		//get the product
		$moreproduct		= explode('#',$this->input->post('id'));
		$id					= $moreproduct[1];
		$data['product']	= $this->Product_model->get_more_product($id);	
		
		$data['base_url']	= $this->uri->segment_array();			
		if($data['product']->images == 'false')
		{
			$data['product']->images = array();
		}
		else
		{
			$data['product']->images	= array_values((array)json_decode($data['product']->images));
		}
		$data['middle_content'] = 'frontend/more_products_model_popup';
					
		echo $this->load->view('frontend/more_products_model_popup',$data);		
	}
	
	
	function quick_product($id)
	{
		//get the product
		$data['product']	= $this->Product_model->get_product($id);
		
		
		if(!$data['product'] || $data['product']->enabled==0)
		{
			show_404();
		}
		
		$data['base_url']			= $this->uri->segment_array();
		
		// load the digital language stuff
		
		$this->load->model('Settings_model');
		
		$data['options']		= $this->Option_model->get_product_options($data['product']->id);
		$data['delivery_areas']	= $this->Settings_model->get_all_delivery_areas();
		
		$related			= $data['product']->related_products;
		$data['related']	= array();
		

				
		$data['posted_options']	= $this->session->flashdata('option_values');

		$data['page_title']			= $data['product']->name;
		$data['meta']				= $data['product']->meta;
		$data['seo_title']			= (!empty($data['product']->seo_title))?$data['product']->seo_title:$data['product']->name;
			
		if($data['product']->images == 'false')
		{
			$data['product']->images = array();
		}
		else
		{
			$data['product']->images	= array_values((array)json_decode($data['product']->images));
		}

		$data['gift_cards_enabled'] = $this->gift_cards_enabled;
		$data['middle_content'] = 'frontend/products_details';		
		$this->load->view('frontend/quick_products_details', $data);
	        
	}
	
	
	function quick_add_to_cart()
	{
		// Get our inputs
		$product_id		= $this->input->post('id');
		$quantity 		= $this->input->post('qty');
		
		
		// Get a cart-ready product array
		$product = $this->Product_model->get_cart_ready_product($product_id, $quantity);
			
			
		$this->load->helper('url');
		if(strpos($this->uri->segment(2), 'search_products') !== false)
		$data['query'] 			= $this->uri->segment(3);
		else 
		$data['query'] 			= 'Search from over 500+ products';
								
		// Add the product item to the cart, also updates coupon discounts automatically
		$this->go_cart->insert($product);
		$this->load->view('frontend/menu',$data);
			
	}
	
	function reload_menu()
	{	
		$this->load->helper('url');
		if(strpos($this->uri->segment(2), 'search_products') !== false)
		$data['query'] 			= $this->uri->segment(3);
		else 
		$data['query'] 			= 'Search from over 500+ products';			
		echo $this->load->view('frontend/menu',$data);
	}
	function reload_mini_cart()
	{				
		echo $this->load->view('frontend/cart');
	}
	
	function view_cart()
	{		
		//$data['posted_options']	= $this->session->flashdata('option_values');
		$data['shipping_charges']		= $this->Settings_model->get_all_shipping_charge();
		$data['page_title']	= 'View Cart';
		$data['gift_cards_enabled'] = $this->gift_cards_enabled;
		$data['middle_content']	= 'frontend/view_cart';
		$this->load->view('templates/subtemplate', $data);
	}
	
	function remove_item($key)
	{
		//drop quantity to 0
		$this->go_cart->update_cart(array($key=>0));
		
		redirect('cart/view_cart');
	}
	
	function remove_item_from_mini_cart()
	{
		$key		= $this->input->post('key');
		//drop quantity to 0
		$this->go_cart->update_cart(array($key=>0));
	
	}
	
	function update_cart($redirect = false)
	{
		//if redirect isn't provided in the URL check for it in a form field
		if(!$redirect)
		{
			$redirect = $this->input->post('redirect');
		}
		
		// see if we have an update for the cart
		$item_keys		= $this->input->post('cartkey');
		$coupon_code	= $this->input->post('coupon_code');
		$gc_code		= $this->input->post('gc_code');
		
		if($coupon_code)
		{
			$coupon_code = strtolower($coupon_code);
		}
			
		//get the items in the cart and test their quantities
		$items			= $this->go_cart->contents();
		$new_key_list	= array();
		//first find out if we're deleting any products
		foreach($item_keys as $key=>$quantity)
		{
			if(intval($quantity) === 0)
			{
				//this item is being removed we can remove it before processing quantities.
				//this will ensure that any items out of order will not throw errors based on the incorrect values of another item in the cart
				$this->go_cart->update_cart(array($key=>$quantity));
			}
			else
			{
				//create a new list of relevant items
				$new_key_list[$key]	= $quantity;
			}
		}
		$response	= array();
		foreach($new_key_list as $key=>$quantity)
		{
			$product	= $this->go_cart->item($key);
			//if out of stock purchase is disabled, check to make sure there is inventory to support the cart.
			if(!$this->config->item('allow_os_purchase') && (bool)$product['track_stock'])
			{
				$stock	= $this->Product_model->get_product($product['id']);
			
				//loop through the new quantities and tabluate any products with the same product id
				$qty_count	= $quantity;
				foreach($new_key_list as $item_key=>$item_quantity)
				{
					if($key != $item_key)
					{
						$item	= $this->go_cart->item($item_key);
						//look for other instances of the same product (this can occur if they have different options) and tabulate the total quantity
						if($item['id'] == $stock->id)
						{
							$qty_count = $qty_count + $item_quantity;
						}
					}
				}
				if($stock->quantity < $qty_count)
				{
					if(isset($response['error']))
					{
						$response['error'] .= '<p>'.sprintf(lang('not_enough_stock'), $stock->name, $stock->quantity).'</p>';
					}
					else
					{
						$response['error'] = '<p>'.sprintf(lang('not_enough_stock'), $stock->name, $stock->quantity).'</p>';
					}
				}
				else
				{
					//this one works, we can update it!
					//don't update the coupons yet
					$this->go_cart->update_cart(array($key=>$quantity));
				}
			}
			else
			{
				$this->go_cart->update_cart(array($key=>$quantity));
			}
		}
		
		//if we don't have a quantity error, run the update
		if(!isset($response['error']))
		{
			//update the coupons and gift card code
			$response = $this->go_cart->update_cart(false, $coupon_code, $gc_code);
			// set any messages that need to be displayed
		}
		else
		{
			$response['error'] = '<p>'.lang('error_updating_cart').'</p>'.$response['error'];
		}
		
		
		//check for errors again, there could have been a new error from the update cart function
		if(isset($response['error']))
		{
			$this->session->set_flashdata('error', $response['error']);
		}
		if(isset($response['message']))
		{
			$this->session->set_flashdata('message', $response['message']);
		}
		
		if($redirect)
		{
			redirect($redirect);
		}
		else
		{
			redirect('cart/view_cart');
		}
	}
	
	
	function removeitem_cart()
	{		
		//see if we have an update for the cart
		$id		= $this->input->post('id');			
		//get the items in the cart and test their quantities
		$items			= $this->go_cart->contents();		
		
		$new_key_list	= array();
		//first find out if we're deleting any products
		foreach($items as $key=>$cartproduct)
		{
			if($cartproduct['id']== $id)
			{
				$quantity = $cartproduct['quantity'] - 1;
				//this item is being removed we can remove it before processing quantities.
				//this will ensure that any items out of order will not throw errors based on the incorrect values of another item in the cart
				$this->go_cart->update_cart(array($key=>$quantity));
			}			
		}
	
		$this->load->view('frontend/menu');
		
	}
	
	

	
	/***********************************************************
			Gift Cards
			 - this function handles adding gift cards to the cart
	***********************************************************/
	
	function giftcard()
	{
		if(!$this->gift_cards_enabled) redirect('/');
		
		// Load giftcard settings
		$gc_settings = $this->Settings_model->get_settings("gift_cards");
				
		$this->load->library('form_validation');
		
		$data['allow_custom_amount']	= (bool) $gc_settings['allow_custom_amount'];
		$data['preset_values']			= explode(",",$gc_settings['predefined_card_amounts']);
		
		if($data['allow_custom_amount'])
		{
			$this->form_validation->set_rules('custom_amount', 'lang:custom_amount', 'numeric');
		}
		
		$this->form_validation->set_rules('amount', 'lang:amount', 'required');
		$this->form_validation->set_rules('preset_amount', 'lang:preset_amount', 'numeric');
		$this->form_validation->set_rules('gc_to_name', 'lang:recipient_name', 'trim|required');
		$this->form_validation->set_rules('gc_to_email', 'lang:recipient_email', 'trim|required|valid_email');
		$this->form_validation->set_rules('gc_from', 'lang:sender_email', 'trim|required');
		$this->form_validation->set_rules('message', 'lang:custom_greeting', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['error']				= validation_errors();
			$data['page_title']			= lang('giftcard');
			$data['gift_cards_enabled']	= $this->gift_cards_enabled;
			$this->view('giftcards', $data);
		}
		else
		{
			
			// add to cart
			
			$card['price'] = set_value(set_value('amount'));
			
			$card['id']				= -1; // just a placeholder
			$card['sku']			= lang('giftcard');
			$card['base_price']		= $card['price']; // price gets modified by options, show the baseline still...
			$card['name']			= lang('giftcard');
			$card['code']			= generate_code(); // from the string helper
			$card['excerpt']		= sprintf(lang('giftcard_excerpt'), set_value('gc_to_name'));
			$card['weight']			= 0;
			$card['quantity']		= 1;
			$card['shippable']		= false;
			$card['taxable']		= 0;
			$card['fixed_quantity'] = true;
			$card['is_gc']			= true; // !Important
			$card['track_stock']	= false; // !Imporortant
			
			$card['gc_info'] = array("to_name"	=> set_value('gc_to_name'),
									 "to_email"	=> set_value('gc_to_email'),
									 "from"		=> set_value('gc_from'),
									 "personal_message"	=> set_value('message')
									 );
			
			// add the card data like a product
			$this->go_cart->insert($card);
			
			redirect('cart/view_cart');
		}
	}
	
	function create_products_view($products)
	{
		$index = 0;
		$products_data = '';
        foreach($products as $product){ 
				  $jsonString = $product->images;			
			      $arrayOfImages=(array)json_decode($jsonString);	
                  $product->images    = array_values($arrayOfImages);
            	  $index++;
                  if(!empty($product->images[0]))
                   {
                     $primary    = $product->images[0];
                     foreach($product->images as $photo)
                     {
                       if(isset($photo->primary))
                       {
                        $primary    = $photo;
                       }
                     }
            $photo  = '<img height="165" width="170" src="'.base_url('uploads/images/small/'.$primary->filename).'" alt="'.$product->seo_title.'"/>';
                 }
                        
         $base_url	= $this->uri->segment_array();
				
		$data['base_url']	= $base_url;
		$base_url			= implode('/', $base_url);
       
        $item ="" ;
        if($index % 5 == 1)
        {
            $item ="first";
        }
        else if($index % 5 == 0)
        {
            $item ="last";
        }
        else
        {
            $item ="";
        }
               $products_data = '<li class="<?php echo $item;?>" style="position:relative;">';                
				//check if current product is in cart
               $quantityincart = 0; $display = 'none'; 				
			   if ($this->go_cart->total_items()>0) {
               foreach ($this->go_cart->contents() as $cartkey=>$cartproduct){
               if( $cartproduct['id']== $product->id) {
               $quantityincart = $cartproduct['quantity'];  $display = 'block';
               break;
			   }
               }
               $products_data .= '<div id="product_cart'.$product->id.'" class="con-text" style="display:'.$display.'">'.$quantityincart.'</div>';
               }
               $products_data.= '<div class="inner"><div id="addcart_div" style="height:35px;"><span id="'.$product->id.'" class="btn_removecart"> - </span> <span id="'.$product->id.'" class="btn_addcart"> + </span></div>';
               $products_data.= '<div class="image"><a href="'.$base_url.$product->slug.'">'.$photo.'</a></div>';
               $products_data.= '<div id="product_name'.$product->id.'class="name"><a href ="'.$base_url.$product->slug.'">'.$product->name.'</a></div>';
               $products_data.= '<div id="product_qty'.$product->id.'" class="price weight">'.$product->weight.'&nbsp;'.$product->unit.'</div>';
               $products_data.= '<div class="price"><span class="sprice">&#8377;&nbsp;'.$product->saleprice.'</span> <span class="mrpprice">MRP &nbsp; &#8377;&nbsp;'.$product->price.'</span></div>';
               $products_data.= '<input type="hidden" name="cartkey" value="'.$this->session->flashdata('cartkey').'" />';
               $products_data.= '<input type="hidden" name="id" value="'.$product->slug.'"/></div></li>';			   
			   } 
			   
	   return $products_data;			
	}
	
	
}