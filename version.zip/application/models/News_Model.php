<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News_Model extends CI_Model {
	
	public function __construct()
	{
	 $this->load->database();	
	}
	
	public function getnews($id)
	{
	 $query = $this->db->get_where('news',array('id'=>$id));
	 return $query->row_array();		
	}
}

/* End of file News.php */
/* Location: ./application/controllers/welcome.php */