<?php
Class Settings_model extends CI_Model
{
	function __construct()
	{
			parent::__construct();
	}
	
	
	
	function get_settings($code)
	{
		$this->db->where('code', $code);
		$result	= $this->db->get('settings');
		
		$return	= array();
		foreach($result->result() as $results)
		{
			$return[$results->setting_key]	= $results->setting;
		}
		return $return;	
	}
	
	/*
	settings should be an array
	array('setting_key'=>'setting')
	$code is the item that is calling it
	ex. any shipping settings have the code "shipping"
	*/
	function save_settings($code, $values)
	{
	
		//get the settings first, this way, we can know if we need to update or insert settings
		//we're going to create an array of keys for the requested code
		$settings	= $this->get_settings($code);
	
		
		//loop through the settings and add each one as a new row
		foreach($values as $key=>$value)
		{
			//if the key currently exists, update the setting
			if(array_key_exists($key, $settings))
			{
				$update	= array('setting'=>$value);
				$this->db->where('code', $code);
				$this->db->where('setting_key',$key);
				$this->db->update('settings', $update);
			}
			//if the key does not exist, add it
			else
			{
				$insert	= array('code'=>$code, 'setting_key'=>$key, 'setting'=>$value);
				$this->db->insert('settings', $insert);
			}
			
		}
		
	}
	
	//delete any settings having to do with this particular code
	function delete_settings($code)
	{
		$this->db->where('code', $code);
		$this->db->delete('settings');
	}
	
	//this deletes a specific setting
	function delete_setting($code, $setting_key)
	{
		$this->db->where('code', $code);
		$this->db->where('setting_key', $setting_key);
		$this->db->delete('settings');
	}
	
	function get_locality($locality_id) 
	{
		$this->db->where('id', $locality_id);
		return $this->db->get('delivery_areas')->result();
	}
	
	function get_latestoffer() 
	{
		
		return $this->db->get('latest_offers')->result();
	}
	
	//zone areas
	function save_latestoffer($data)
	{
	
			$this->db->where('id', $data['id']);
			$this->db->update('latest_offers', $data);
			return $data['id'];
		
	}
	
	
	function get_all_delivery_areas()
	{
		return $this->db->get('delivery_areas')->result();
	}
	
	//zone areas
	function save_locality($data)
	{
		if(!$data['id']) 
		{
			$this->db->insert('delivery_areas', $data);
			return $this->db->insert_id();
		} 
		else 
		{
			$this->db->where('id', $data['id']);
			$this->db->update('delivery_areas', $data);
			return $data['id'];
		}
	}
	
	function delete_delivery_area($id)
	{
		$this->db->where('id', $id)->delete('delivery_areas');
	}
	
	
	function get_shipping_charges($locality_id) 
	{
		$this->db->where('id', $locality_id);
		return $this->db->get('shipping_charge')->result();
	}
	
	function delete_shipping_charge($id)
	{
		$this->db->where('id', $id)->delete('shipping_charge');
	}
	
	
	//zone areas
	function save_shipping_charge($data)
	{
		if(!$data['id']) 
		{
			$this->db->insert('shipping_charge', $data);
			return $this->db->insert_id();
		} 
		else 
		{
			$this->db->where('id', $data['id']);
			$this->db->update('shipping_charge', $data);
			return $data['id'];
		}
	}
	
	function get_all_shipping_charge()
	{
		return $this->db->get('shipping_charge')->result();
	}
	function get_free_shipping_value($subtotal)
	{
		$this->db->where('shipping_charge', '0.00');
		$freeship = $this->db->get('shipping_charge')->row()->frm_order_amount;
		if($subtotal> $freeship || $subtotal<1)
		return '0.00';
		else
		{
		$this->db->where('frm_order_amount <', $subtotal);
		$this->db->where('to_order_amount  >=', $subtotal);
		return $this->db->get('shipping_charge')->row()->shipping_charge;
		
		}
	}
}