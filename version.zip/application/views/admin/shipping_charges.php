<script type="text/javascript">
function areyousure()
{
	return confirm('<?php echo lang('confirm_delete');?>');
}
</script>

<div style="text-align:right;">
	<a class="btn" href="<?php echo site_url($this->config->item('admin_folder').'/settings/shipping_charge_form'); ?>"><i class="icon-plus-sign"></i> <?php echo lang('add_new_delivery_area');?></a>
</div>

<table class="table table-striped">
	<thead>
		<tr>
			<th><?php echo lang('order_amount');?></th>
			<th><?php echo lang('delivery_charge');?></th>
			
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php foreach ($shipping_charges as $shipping_charge):?>
		<tr>
			<td><?php echo $shipping_charge->frm_order_amount.'  -  '. $shipping_charge->to_order_amount; ?></td><td><?php echo $shipping_charge->shipping_charge; ?></td>
			<td>
				<div class="btn-group" style="float:right;">
					
					<a class="btn btn-danger" href="<?php echo site_url($this->config->item('admin_folder').'/settings/delete_shipping_charge/'.$shipping_charge->id); ?>" onclick="return areyousure();"><i class="icon-trash icon-white"></i> <?php echo lang('delete');?></a>
					
				</div>
			</td>
		</tr>
<?php endforeach; ?>
	</tbody>
</table>