<?php echo form_open($this->config->item('admin_folder').'/settings/form/'.$id); ?>
	
		<label><?php echo 'Locality Name';?></label>
		<?php
		$data	= array('name'=>'locality_name', 'value'=>set_value('locality_name', $locality_name));
		echo form_input($data);
		?>
		
		
		
		<div class="form-actions">
			<input class="btn btn-primary" type="submit" value="<?php echo lang('save');?>"/>
		</div>
	
</form>
<script type="text/javascript">
$('form').submit(function() {
	$('.btn').attr('disabled', true).addClass('disabled');
});
</script>