<?php echo form_open($this->config->item('admin_folder').'/settings/latestoffers/'.$id); ?>
	
		<label><?php echo 'Offer Details';?></label>
		<?php
		$data	= array('name'=>'offer_name',  'rows'=>'4', 'value'=>set_value('offer_name', $offer_details));
		echo form_textarea($data);
		?>
		
		
		
		<div class="form-actions">
			<input class="btn btn-primary" type="submit" value="<?php echo lang('save');?>"/>
		</div>
	
</form>
<script type="text/javascript">
$('form').submit(function() {
	$('.btn').attr('disabled', true).addClass('disabled');
});
</script>