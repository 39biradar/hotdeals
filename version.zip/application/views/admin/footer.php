<footer>
<div style="text-align:center;"><a href="http://gocartdv.com" target="_blank"></div>
    </footer>
</div>

</body>
</html>