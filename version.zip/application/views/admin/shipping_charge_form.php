<?php echo form_open($this->config->item('admin_folder').'/settings/save_shipping_charge/'.$id); ?>

<label><?php echo lang('order_amount');?></label>
<?php
		$options = array (	'000 - 100'		=> '000 - 100',
							'101 - 150'	=> '101 - 150','151 - 200'	=> '151 - 200','201 - 250'	=> '201 - 250','251 - 301'	=> '251 - 301'
		                );
		echo form_dropdown('order_amount', $options, set_value('order_amount', $order_amount));
		?>
		
<label><?php echo lang('delivery_charge');?></label>
<?php
		$options = array(	'0'		=> '0','10'		=> '10',
							'15'	=> '15','20'	=> '20','25'	=> '25','30'	=> '30','40'	=> '40','50'	=> '50','60'	=> '60','70'	=> '70'
							,'80'	=> '80','90'	=> '90','100'	=> '100'
		                );
		echo form_dropdown('shipping_charge', $options, set_value('shipping_charge', $shipping_charge));
		?>
<div class="form-actions">
  <input class="btn btn-primary" type="submit" value="<?php echo lang('save');?>"/>
</div>
</form>
<script type="text/javascript">
$('form').submit(function() {
	$('.btn').attr('disabled', true).addClass('disabled');
});
</script>
