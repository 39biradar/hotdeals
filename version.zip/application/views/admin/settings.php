<?php echo form_open_multipart(config_item('admin_folder').'/settings');?>

<fieldset>
<legend><?php echo lang('shop_details');?></legend>
<div class="row">
  <div class="span4">
    <label><?php echo lang('company_name');?></label>
    <?php echo form_input(array('class'=>'span4', 'name'=>'company_name', 'value'=>set_value('company_name', $company_name)));?> </div>
  <div class="span4">
    <label><?php echo lang('address1');?></label>
    <?php echo form_input(array('name'=>'address1', 'class'=>'span12','value'=>set_value('address1',$address1)));?> </div>
  <div class="span4">
    <label><?php echo lang('address2');?></label>
    <?php echo form_input(array('name'=>'address2', 'class'=>'span12','value'=> set_value('address2',$address2)));?></div>
</div>
<div class="row">
  <div class="span4">
    <label><?php echo lang('country');?></label>
    <?php echo form_dropdown('country_id', $countries_menu, set_value('country_id', $country_id), 'id="country_id" class="span12"');?> </div>
  <div class="span4">
    <label><?php echo lang('city');?></label>
    <?php echo form_input(array('name'=>'city','class'=>'span4', 'value'=>set_value('city',$city)));?> </div>
  <div class="span4">
    <label><?php echo lang('state');?></label>
    <?php echo form_dropdown('zone_id', $zones_menu, set_value('zone_id', $zone_id), 'id="zone_id" class="span6"');?> </div>
  <div class="span4">
    <label><?php echo lang('zip');?></label>
    <?php echo form_input(array('maxlength'=>'10', 'class'=>'span2', 'name'=>'zip', 'value'=> set_value('zip',$zip)));?> </div>
</div>
</fieldset>
<input type="submit" class="btn btn-primary" value="<?php echo lang('save');?>" />
</form>
<script>
    $(document).ready(function(){
        $('#country_id').change(function(){
            $.post('<?php echo site_url(config_item('admin_folder').'/locations/get_zone_menu');?>',{id:$('#country_id').val()}, function(data) {
              $('#zone_id').html(data);
            });
        });
    });
    
    function htmlEntities(str) {
       return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }      
</script>
<style type="text/css">
#order_statuses_json {
   display:none;
}
</style>
