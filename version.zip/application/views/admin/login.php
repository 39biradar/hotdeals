<?php include('header.php'); ?>

<div >
    
    <div  style="margin: 0 auto;width: 300px;height: 400px;">
	<h2>Admin Login</h2>


    <?php echo form_open('admin/login') ?>
    
    <fieldset>
       <b> <label for="username"><?php echo "Username" ?></label> </b>
       
        <?php echo form_input(array('name'=>'username')); ?>
        
        
         <b><label for="password" style="margin-top: 10px;"><?php echo "password" ?></label></b>
        <?php echo form_password(array('name'=>'password')); ?>
        
        <label class="checkbox">
            <?php echo form_checkbox(array('name'=>'remember', 'value'=>'false'))?>
            <?php echo "stay loged in" ?>
        </label>
        
            <input class="button" type="submit" value="<?php echo "login" ?>"/>
        
        
        <input type="hidden" value="<?php echo $redirect; ?>" name="redirect"/> 
        <input type="hidden" value="submitted" name="submitted"/>
        
    </fieldset>
    <?php echo  form_close(); ?>
	</div>
	
</div>

<?php include('footer.php'); ?>