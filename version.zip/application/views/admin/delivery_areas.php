<script type="text/javascript">
function areyousure()
{
	return confirm('<?php echo lang('confirm_delete');?>');
}
</script>

<div style="text-align:right;">
	<a class="btn" href="<?php echo site_url($this->config->item('admin_folder').'/settings/form'); ?>"><i class="icon-plus-sign"></i> <?php echo lang('add_new_delivery_area');?></a>
</div>

<table class="table table-striped">
	<thead>
		<tr>
			<th><?php echo lang('delivery_area_name');?></th>
			
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php foreach ($delivery_area as $deliveryarea):?>
		<tr>
			<td><?php echo $deliveryarea->locality_name; ?></td>
			<td>
				<div class="btn-group" style="float:right;">	
					<?php
					$margin			= 30;?>
					
					<a class="btn btn-danger" href="<?php echo site_url($this->config->item('admin_folder').'/settings/delete/'.$deliveryarea->id); ?>" onclick="return areyousure();"><i class="icon-trash icon-white"></i> <?php echo lang('delete');?></a>
					
				</div>
			</td>
		</tr>
<?php endforeach; ?>
	</tbody>
</table>