<!-- header starts here -->
<?php $this->load->view('frontend/header'); ?>

<!-- header starts here -->
<?php $this->load->view('frontend/cart'); ?>

<!-- header starts here -->
<?php $this->load->view('frontend/menu'); ?>


<!-- header starts here -->
<?php $this->load->view($middle_content); ?>

<!-- header starts here -->
<?php $this->load->view('frontend/footer'); ?>