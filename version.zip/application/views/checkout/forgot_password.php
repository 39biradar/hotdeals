<style>#search {display:none;}</style>
<div class="wrapper">
    <div id="notification"></div>
    <div id="container">
      <div id="content">
<div style="margin-top:50px;">
	<div>
	<fieldset>
			<table class="form" style="margin:0 auto;width: auto;!important;">
        <tbody>
		<tr ><td>
			<h1><?php echo lang('forgot_password');?></h1>
		</td></tr>
		<?php echo form_open('secure/forgot_password', 'class="form-horizontal"') ?>
         
					<tr><td>
						<label class="control-label" for="email"><?php echo lang('email');?></label>
						<div class="controls">
							<input type="text" name="email" class="span3"/>
						</div>
					</td></tr>
					<tr><td>
						<label class="control-label"></label>
						<div class="controls">
							<input type="hidden" value="submitted" name="submitted"/>
							<input type="submit" value="<?php echo lang('reset_password');?>" name="submit" class="button"/>
						</div>
					</td> <td><a href="<?php echo site_url('secure/login'); ?>"><?php echo lang('return_to_login');?></a></td>  </tr>
			</tbody>
      </table>
	</fieldset>
		</form>
	</div>
</div>
 </div>
      <div class="clear"></div>
    </div>
  </div>