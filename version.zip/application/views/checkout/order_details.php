<style>#search {display:none;}</style>
<div class="info_sectiom">
  <?php if(config_item('require_shipping')):?>
  <?php if($this->go_cart->requires_shipping()):?>
  <div class="right_info" > <a href="<?php echo site_url('checkout/shipping_address');?>" class="button"><?php echo lang('shipping_address_button');?></a>
    <table style="width:100%;">
    <tr> <td>
<?php echo $customer['ship_address']['firstname'].' '.$customer['ship_address']['lastname']?>  </td></tr>
    <tr> <td> <?php echo $customer['ship_address']['address1'];?>  </td></tr>
    <tr> <td> <?php echo $customer['ship_address']['city'];?>  </td></tr>
    <tr> <td> <?php echo $customer['ship_address']['phone'];?> </td></tr>
    <tr> <td> <?php echo $customer['ship_address']['email'];?> </td></tr>
  </table></div>

  <div class="left_info">
  <p> <?php  $deliveryslot = $this->go_cart->delivery_date_time(); if(strpos($deliveryslot['time'],'90 minutes')!== false){  echo '<span style="color:#0fbe7c">Your order will be delivered in next : </span>'.$deliveryslot['time'];} else { echo '<span style="color:#0fbe7c">Your order will be delivered on : </span>'.$deliveryslot['date'].'<span style="color:#0fbe7c"> between </span>'.$deliveryslot['time'];} ?></p>
  <p><a href="<?php echo site_url('checkout/');?>" class="button"><?php echo lang('change_delivery_time');?></a></p>
  <strong><?php echo lang('cash_on_delivery');?></strong><br/>
  </div>
 
  <?php endif;?>
  <?php endif;?>
  <?php if(!empty($payment_method)):?>
  <div class="right_info">
    <p><a href="<?php echo site_url('checkout/step_3');?>" class="button"><?php echo lang('billing_method_button');?></a></p>
    <?php echo $payment_method['description'];?> </div>
  <?php endif;?>
</div>
