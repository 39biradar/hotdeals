<script src="<?php echo base_url();?>assets/js/custom.js"></script>
<style>
table.form td {
    padding: 10px !important;
}
</style>
<?php

$f_id		= array('id'=>'f_id', 'style'=>'display:none;', 'name'=>'id', 'value'=> set_value('id',$id));
$f_address1	= array('id'=>'f_address1', 'class'=>'span12', 'name'=>'address1', 'value'=>set_value('address1',$address1));
$f_first	= array('id'=>'f_firstname', 'class'=>'span12', 'name'=>'firstname', 'value'=> set_value('firstname',$firstname));
$f_last		= array('id'=>'f_lastname', 'class'=>'span12', 'name'=>'lastname', 'value'=> set_value('lastname',$lastname));
$f_email	= array('id'=>'f_email', 'class'=>'span12', 'name'=>'email', 'value'=>set_value('email',$email));
$f_phone	= array('id'=>'f_phone', 'class'=>'span12', 'name'=>'phone', 'value'=> set_value('phone',$phone));
$f_city		= array('id'=>'f_city', 'class'=>'span12', 'name'=>'city', 'value'=>set_value('city',$city));
$f_zip		= array('id'=>'f_zip', 'maxlength'=>'10', 'class'=>'span12', 'name'=>'zip', 'value'=> set_value('zip',$zip));

echo form_input($f_id);

?>

<div style="background:#fff;height:370px;width:500px;padding-top:40px;">
  <div>
    <table class="form" style="margin:0 auto;width:auto !important">
      <tbody>
        <tr>
          <td><?php echo form_input($f_first);?> </td>
        </tr>
        <tr>
          <td><?php echo form_input($f_last);?> </td>
        </tr>
        <tr>
          <td><?php echo form_input($f_email);?> </td>
        </tr>
        <tr>
          <td><?php echo form_input($f_phone);?> </td>
        </tr>
        <tr>
          <td><?php echo form_input($f_address1);?> </td>
        </tr>
        <tr>
          <td><?php echo form_dropdown( 'city',  array('Delhi' => 'Delhi','Gurgaon' => 'Gurgaon'), set_value('city', ''),'id="f_city"'); ?> </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div style="height:50px;text-align:center;"> <a href="#" id="model_close" class="button" type="button" onclick="save_address(); return false;"><?php echo lang('form_submit');?></a> </div>
</div>
</div>
<script >	
function save_address()
{	
	$.post("<?php echo site_url('secure/address_form');?>/"+$('#f_id').val(), {																						   																				firstname: $('#f_firstname').val(),
																				lastname: $('#f_lastname').val(),
																				email: $('#f_email').val(),
																				phone: $('#f_phone').val(),
																				address1: $('#f_address1').val(),
																				city: $('#f_city').val()																				
																				},
		function(data){
			if(data == 1)
			{
				
				window.location = "<?php echo site_url('secure/my_account');?>";
				$('#model_close').flythat({show: false}); //close the model on page load
			}
			else
			{
				$('#form-error').html(data).show();
			}
		});
}
</script>
