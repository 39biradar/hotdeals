<style>#search {display:none;}</style>
<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div class="home_menu">
      <style type="text/css">
.placeholder {display:none;}
</style>
      <?php if (validation_errors()):?>
      <div class="alert alert-error"> <a class="close" data-dismiss="alert">x</a> <?php echo validation_errors();?> </div>
      <?php endif;?>
      <?php
	//post to the correct place.
	echo ($address_form_prefix == 'bill')?form_open('checkout/step_1'):form_open('checkout/shipping_address');?>
      <table class="form" style="margin:0 auto;width:auto !important">
        <tbody>
          <tr>
            <td><h4 style="margin:0px;"> <?php echo ($address_form_prefix == 'bill')?lang('address'):lang('shipping_address');?> </h4></td>
          </tr>
          <tr>
            <td><label class="placeholder"><?php echo lang('address_firstname');?><b class="r"> *</b></label>
              <?php
			$data	= array('name'=>'firstname', 'placeholder'=> lang('address_firstname'), 'value'=>set_value('firstname', $customer['firstname']), 'class'=>'address span4');
			echo form_input($data); ?>
            </td>
          </tr>
          <tr>
            <td><label class="placeholder"><?php echo lang('address_lastname');?><b class="r"> *</b></label>
              <?php
			$data	= array('name'=>'lastname', 'placeholder'=> lang('address_lastname'), 'value'=>set_value('lastname',$customer['lastname']), 'class'=>'address span4');
			echo form_input($data); ?>
            </td>
          </tr>
          <tr>
            <td><label class="placeholder"><?php echo lang('address_email');?><b class="r"> *</b></label>
              <?php  
				$data		= array('placeholder'=>lang('address_email'), 'class'=>'address span4', 'name'=>'email', 'value'=> set_value('email', $customer['email']));
				echo form_input($data);?>
            </td>
          </tr>
          <tr>
            <td><label class="placeholder"><?php echo lang('address_phone');?><b class="r"> *</b></label>
              <?php 
				$data		= array('placeholder'=>lang('address_phone'), 'class'=>'address span4', 'name'=>'phone', 'value'=> set_value('phone', $customer['phone']));
				echo form_input($data);?>
            </td>
          </tr>
          <tr>
            <td><label class="placeholder"><?php echo lang('address1');?><b class="r"> *</b></label>
              <?php
			$data	= array('placeholder'=>lang('address1'), 'class'=>'address span8', 'name'=>'address1', 'value'=> set_value('address1', $customer['address1']));
				 echo form_input($data);?>
            </td>
          </tr>
          <tr>
            <td ><label class="placeholder"><?php echo lang('address_city');?><b class="r"> *</b></label>
              <?php echo form_dropdown( 'city',  array('Delhi' => 'Delhi','Gurgaon' => 'Gurgaon'), set_value('city', $customer['city']));?> </td>
          </tr>
          <tr><td> <label class="checkbox inline" for="use_shipping" style="display:none;"> <?php echo form_checkbox(array('name'=>'use_shipping', 'value'=>'yes', 'id'=>'use_shipping',  'checked'=>true)) ?> <?php echo lang('ship_to_address') ?> </label></td> </tr>
          <tr>
            <td><input id="submit"   type="submit" value="<?php echo lang('form_continue');?>"/>
            </td>
          </tr>
        </tbody>
      </table>
      </form>
    </div>
  </div>
</div>
<div class="clear"></div>
</div>
</div>
