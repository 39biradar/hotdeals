<form enctype="multipart/form-data" method="post" action="#">
<div class="cart-info">
  <table>
    <thead>
      <tr>
        <td class="image"> Image</td>
        <td class="name">Item</td>
		<td class="price">Price</td>
        <td class="quantity">Quantity</td>
        <td class="total">Total</td>
      </tr>
    </thead>
    <tbody>
      <?php
			$subtotal = 0;
			$index = 0; 
			foreach ($this->go_cart->contents() as $cartkey=>$product):?>
      <?php  
			$jsonString = $product['images'];			
			$arrayOfImages=(array)json_decode($jsonString);			
		 	$item_product->images    = array_values($arrayOfImages);
            			$index++;
                        if(!empty($item_product->images[0]))
                        {
                            $primary    = $item_product->images[0];
                            foreach($item_product->images as $photo)
                            {
                                if(isset($photo->primary))
                                {
                                    $primary    = $photo;
                                }
                            }

         $photo  = '<img height="80" width="80" src="'.base_url('uploads/images/small/'.$primary->filename).'" />';
                  }
         ?>
      <tr>
        <td class="image"><a href=""><?php echo $photo; ?></a></td>
        <td class="name"><a href=""><?php echo $product['name']; ?></a> </td>
       
						
					
        <td class="price">
		<?php 
							if(isset($product['options'])) {
								foreach ($product['options'] as $name=>$value)
								{
										 $value;
									
								}
							}
							?>
		
		<?php echo $product['currency']."&nbsp;".$product['price'].'&nbsp;/'.$product['weight'].$product['unit']; ?></td>
        <td class="quantity"><?php if($this->uri->segment(1) == 'cart'): ?>
          <?php if(!(bool)$product['fixed_quantity']):?>
          <input class="w30" style="margin:0px;" name="cartkey[<?php echo $cartkey;?>]"  value="<?php echo $product['quantity'] ?>" size="3" type="text">
          <a  onclick="if(confirm('<?php echo lang('remove_item');?>')){ window.location='<?php echo site_url('cart/remove_item/'.$cartkey);?>';}"><img src="<?php echo base_url(); ?>assets/images/remove.png" alt="" width="15" height="15"  border="0"></img></a>
          <?php else:?>
          <?php echo $product['quantity'] ?>
          <input type="hidden" name="cartkey[<?php echo $cartkey;?>]" value="1"/>
          <a  onclick="if(confirm('<?php echo lang('remove_item');?>')){ window.location='<?php echo site_url('cart/remove_item/'.$cartkey);?>';}"><img src="<?php echo base_url(); ?>assets/images/remove.png" alt="" border="0"></img></a>
          <?php endif;?>
          <?php else: ?>
          <?php echo $product['quantity'] ?>
          <?php endif;?>
        </td>
        <td class="total"><img  height="10" width="8" src="<?php echo base_url('assets/images/rupee_icon.png')?>"/>&nbsp;<?php echo ($product['price']*$product['quantity']); ?></td>
      </tr>
      <?php endforeach;?>
    </tbody>
  </table>
</div>
<div class="cart-total">
    <table id="total">
      <tbody>
	  <tr>
       <td class="right"><b><?php echo lang('subtotal');?>:</b></td><td class="right"><img  height="10" width="8" src="<?php echo base_url('assets/images/rupee_icon.png')?>"/>&nbsp;<?php echo $this->go_cart->subtotal(); ?></td>
      </tr>
	   <tr>
	   	   
        <td class="right"><b><?php echo 'Shipping Charge';?>:</b></td>        <td class="right"><img  height="10" width="8" src="<?php echo base_url('assets/images/rupee_icon.png')?>"/>&nbsp;			<?php echo $this->go_cart->shipping_charge(); ?></td>
      </tr>
      <tr>
        <td class="right"><b><?php echo lang('grand_total');?>:</b></td>
        <td class="right"><img  height="10" width="8" src="<?php echo base_url('assets/images/rupee_icon.png')?>"/>&nbsp;<?php echo $this->go_cart->total(); ?></td>
      </tr>
    </tbody></table>
  </div>
