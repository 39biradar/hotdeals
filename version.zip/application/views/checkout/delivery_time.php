<style>#search {display:none;}</style>
<script>
$(document).ready(function(){
 var $submitbtn = jQuery('#submit');
//$submitbtn.attr('disabled', 'disabled');
//$submitbtn.css({opacity:'0.3'}); 
  $('input').iCheck({
    checkboxClass: 'icheckbox_square-red',
    radioClass: 'iradio_square-green',
    increaseArea: '20%' // optional
  });
  $('input').on('ifChecked', function(event){ 	  
	  if($(this).val().contains('90 minutes')){
	  var dateslot = $(this).val().split('#');;
	  $("#span_selected_time").html('<span style="color:#0fbe7c">Your order will be delivered Today in next :  </span>'+ dateslot[1]);
	  $submitbtn.removeAttr('disabled');
	  $submitbtn.css({opacity:'1'});
	  //set the selected value to a hidden field
	  $("#selected_delivery_time").val($(this).val());
	 
	  	  
	  }
	  else {
	  var dateslot = $(this).val().split('#');
	  $("#span_selected_time").html('<span style="color:#0fbe7c">Your order will be delivered on : </span>'+  dateslot[0] + '<span style="color:#0fbe7c"> between </span>' + dateslot[1]);
	  $submitbtn.removeAttr('disabled');
	  $submitbtn.css({opacity:'1'});
	  //set the selected value to a hidden field
	  $("#selected_delivery_time").val($(this).val());

	  }
    });
  
});
</script>

<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
   <div class="home_menu">
     <style type="text/css">.placeholder {display:none;}</style>
	<?php if (validation_errors()):?>
      <div class="alert alert-error"> <a class="close" data-dismiss="alert">x</a> <?php echo validation_errors();?> </div>
      <?php endif;?>
      
      <?php echo form_open('checkout/delivery_datetime');?>
      
       <?php $deliveryslot = $this->go_cart->delivery_date_time(); if(strlen($deliveryslot['time'])>1) :
	    if (strpos($deliveryslot['time'], '90 minutes') !== FALSE):
         $values =  '<span style="color:#0fbe7c">Your order will be delivered Today in next :  </span>'.$deliveryslot['time']; ?>		
       
	   <div class="selected_delivery_time"><span id="span_selected_time"><?php echo $values?> </span> </div>
	   <?php else :
	    $values =  '<span style="color:#0fbe7c">Your order will be delivered on :  </span>'.$deliveryslot['date'].'<span style="color:#0fbe7c"> between </span>' .$deliveryslot['time']; ?>	 
       <div class="selected_delivery_time"><span id="span_selected_time"><?php echo $values?> </span> </div>
	   
        <?php endif;?>
        <?php else :?>
         <div class="selected_delivery_time"><span id="span_selected_time"> </span> </div>
	  <?php endif;?>
           
      <div class="deliverin90mins">
       <input   type="hidden" name="selected_delivery_time" value="<?php echo $delivery_time; ?>"  id="selected_delivery_time" placeholder=""/>
      <span id="selected_datetime_ingocart" style="display:none;"></span>   
       <?php $date = new DateTime("now",new DateTimeZone("Asia/Kolkata"));  ?>
     <span style="margin-left:10px;"> <input value="<?php echo $date->format("d-m-Y").'#'.'90 minutes' ?>" tabindex="4"  type="radio" id="input-4" name="demo-radio" <?php if(strpos($delivery_time,'90 minutes') !== false){echo 'checked="checked"'; } ?> > </span>  Deliver within next 90 minutes  </div>
     
       <label style="text-align:center;font-size:16px;color:#e85d4a;margin:5px 0;font-weight:bold;"> Or </label>
	  <?php $delivery_slots = array('10:00 AM - 12:30 PM','13:00 PM - 15:00 PM','16:00 AM - 20:00 PM');?>
      <div class="delivery_time_head">
      <?php for($i=0; $i<count($delivery_slots); $i++) : ?>
      <div class="delivery_time_head_slot"><?php echo $delivery_slots[$i]; ?> </div>
      <!-- end of for loop for delivery slots -->
      <?php endfor;?> 
      </div>
      <div>  
      <?php $cursor=new DateTime("now",new DateTimeZone("Asia/Kolkata")); 
	  
	  //if delivery date time already selected then we have to check the corresponding radio buttons
	   $previous_selected = explode('#',$delivery_time);//delivery is coming from controller
	   $previous_date = $previous_selected[0];
	   $previous_time_range = explode('-',$previous_selected[1]);//get timepart at position 1
	   $previous_time  = preg_replace('/[a-zA-Z]/', '', $previous_time_range);
	  
	   $previous_selected_opn_timestamp = strtotime($previous_date.' '.$previous_time[0]); 
		  
	  // we want the delivery schedule only for 3 days 
	  for ($deliverydate = 1; $deliverydate<=3; $deliverydate++) : ?>
      <div style="height:32px;padding: 0 auto;"> <label style="float:left;"><?php echo $cursor->format("D,  d S M") ?></label>
      <div class="delivery_time_right"> 
	  <?php for ($radiobtn = 0;$radiobtn < count($delivery_slots);$radiobtn++) : 
      //get the start time from ranges and remove any AM or PM from it
	  $timeslot = split ('-', $delivery_slots[$radiobtn]); // get the delivery slot from delivery slot array at postion $radiobtn
	  $starttime = preg_replace('/[a-zA-Z]/', '', $timeslot);
	  //echo $cursor->format('d-m-Y').'#'.$starttime[0]; 
	
	  if ($deliverydate ==1) :
  	  $date = new DateTime(null, new DateTimeZone('Asia/Kolkata'));
	    //if timeslot's start time has been for past fot the current date then disable radio btn  
		  if(strtotime($date->format('d-m-Y H:i:s')) >= strtotime($date->format('d-m-Y').' '.$starttime[0])) : ?>
			<div class="delivery_time_radio_btn"><input value="<?php echo $cursor->format("d-m-Y").'#'.$delivery_slots[$radiobtn]; ?>" tabindex="4" type="radio" id="input-4"  <?php if($previous_selected_opn_timestamp == strtotime($cursor->format('d-m-Y').' '.$starttime[0])){echo 'checked="checked"'; } ?>    name="demo-radio" disabled="disabled" ></div>
		   <?php else : ?>
		   <div class="delivery_time_radio_btn"><input value="<?php echo $cursor->format("d-m-Y").'#'.$delivery_slots[$radiobtn]; ?>" tabindex="4" type="radio" id="input-4" <?php if($previous_selected_opn_timestamp == strtotime($cursor->format('d-m-Y').' '.$starttime[0])){echo 'checked="checked"'; } ?>  name="demo-radio"  ></div>
		  <?php endif;?>
          
     <?php else : ?> <!-- else part if delivery date is not today's date then put all enabled buttons -->
      <div class="delivery_time_radio_btn"><input value="<?php echo $cursor->format("d-m-Y").'#'.$delivery_slots[$radiobtn]; ?>" tabindex="4" type="radio" id="input-4" <?php if($previous_selected_opn_timestamp == strtotime($cursor->format('d-m-Y').' '.$starttime[0])){echo 'checked="checked"'; } ?>  name="demo-radio"  ></div>
     <?php endif;?> <!-- end if deliverydate ==1  -->
     
     <?php endfor;?>  </div></div>
     <!-- end of the delivery dates for loop --> 
     <?php $cursor->modify("+1 day");  endfor;?>    
	 </div> 
     <div style="margin:40px 0;text-align:center;">
    <?php if(strlen($delivery_time)<1)   
      { $disabled="disabled=disabled";$opacity="style=opacity:.3"; } else { $disabled="";$opacity="style=opacity :1"; } ?> 
     <input id="submit" <?php echo $disabled.' '.$opacity; ?>  type="submit" value="<?php echo lang('form_continue');?>"/>
     </div> 
     </form>	
    </div>
  </div>
  <div class="clear"></div>
</div>
</div>
