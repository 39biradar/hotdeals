<style>#search {display:none;}</style>
<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div class="home_menu"> 
	<?php echo form_open('checkout/place_order');?>
      <div class="page-header">
        <h2><?php echo lang('confirm_order');?></small></h2>
      </div>
      <?php include('order_details.php');?>
      <div class="span12">
        <?php include('summary.php');?>
      </div>
      <div class="row">
        <div style="margin:40px 0 0 0;text-align:right;padding-bottom:100px;">
          <input id="submit" type="submit" value="<?php echo lang('submit_order');?>"/>
        </div>
      </div>
      </form>
    </div>
    <div class="clear"></div>
  </div>
</div>
