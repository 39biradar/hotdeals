<style>#search {display:none;}</style>
<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div class="home_menu"> 
      <div>
        <h2><?php echo lang('order_number');?>: <?php echo $order_id;?></h2>
      </div>
      <div class="info_sectiom">
        <div class="right_info">
          <h3><?php echo lang('shipping_information');?></h3>
          <?php echo $customer['firstname'];?> <?php echo $customer['lastname'];?><br/>
          <?php echo $customer['address1'];?><br/>
          <?php echo $customer['city'];?><br/>
          <?php echo $customer['email'];?> <br/>
          <?php echo $customer['phone'];?> <br/>
          
       </div>
       
        <div class="left_info">     
        <p> <?php  if(strpos($delivery_time,'90 minutes')!== false){  echo '<span style="color:#0fbe7c">Your order will be delivered in next : </span>'.$delivery_time;} else { echo '<span style="color:#0fbe7c">Your order will be delivered on : </span>'.$delivery_date.'<span style="color:#0fbe7c"> between </span>'.$delivery_time;} ?></p> <strong><?php echo lang('cash_on_delivery');?></strong><br/>       
      </div>
      
     <div style="height:auto;">
      <table class="table table-bordered table-striped" style="margin-top:20px;float:left;">
        <thead>
          <tr>
            <th style="width:10%;"><?php echo lang('sku');?></th>
            <th style="width:20%;"><?php echo lang('name');?></th>
            <th style="width:10%;"><?php echo lang('price');?></th>
            <th style="width:10%;"><?php echo lang('quantity');?></th>
            <th style="width:8%;"><?php echo lang('totals');?></th>
          </tr>
        </thead>
        <tfoot>
          <?php if($go_cart['group_discount'] > 0)  : ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('group_discount');?></strong></td>
            <td><?php echo $go_cart['group_discount']; ?></td>
          </tr>
          <?php endif; ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('subtotal');?></strong></td>
            <td><?php echo $go_cart['subtotal']; ?></td>
          </tr>
          <?php if($go_cart['coupon_discount'] > 0)  : ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('coupon_discount');?></strong></td>
            <td><?php echo $go_cart['coupon_discount']; ?></td>
          </tr>
          <?php if($go_cart['order_tax'] != 0) : // Only show a discount subtotal if we still have taxes to add (to show what the tax is calculated from) ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('discounted_subtotal');?></strong></td>
            <td><?php echo $go_cart['discounted_subtotal']; ?></td>
          </tr>
          <?php endif;

		endif; ?>
          <?php // Show shipping cost if added before taxes
		if($this->config->item('tax_shipping') && $go_cart['shipping_cost']>-1) : ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('shipping_charge');?></strong></td>
            <td><?php echo $go_cart['shipping_cost']; ?></td>
          </tr>
          <?php endif ?>
          <?php if($go_cart['order_tax'] != 0) : ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('taxes');?></strong></td>
            <td><?php echo $go_cart['order_tax']; ?></td>
          </tr>
          <?php endif;?>
          <?php // Show shipping cost if added after taxes
		if(!$this->config->item('tax_shipping') && $go_cart['shipping_cost']>0) : ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('shipping');?></strong></td>
            <td><?php echo $go_cart['shipping_cost']; ?></td>
          </tr>
          <?php endif;?>
          <?php if($go_cart['gift_card_discount'] != 0) : ?>
          <tr>
            <td colspan="4"><strong><?php echo lang('gift_card');?></strong></td>
            <td><?php echo $go_cart['gift_card_discount']; ?></td>
          </tr>
          <?php endif;?>
          <tr>
            <td colspan="4"><strong><?php echo lang('grand_total');?></strong></td>
            <td><?php echo $go_cart['total']; ?></td>
          </tr>
        </tfoot>
      
        <tbody>
          <?php
	$subtotal = 0;
	foreach ($go_cart['contents'] as $cartkey=>$product):?>
          <tr>
            <td><?php echo $product['sku'];?></td>
            <td><?php echo $product['name']; ?></td>
            <td><?php echo $product['base_price'];   ?></td>
            <td><?php echo $product['quantity'];?></td>
            <td><?php echo $product['price']*$product['quantity']; ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</div>
