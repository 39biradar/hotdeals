<!--Cart Part Start-->
<?php error_reporting(E_ERROR);?>
<script type="text/javascript"> 
jQuery(document).ready(function(){
$('.remove_item_from_mini_cart11').click(function (e) {
        e.preventDefault();		
        var key = this.id; 
        $.ajax({
            type: "POST",
            data:'key='+key,
            url:'<?php echo site_url('cart/remove_item_from_mini_cart'); ?>',
            success: function(respond)
                {
				$.get('<?php echo site_url('cart/reload_menu'); ?>', function(cart) {
				$("#menu_div").html(cart);});
				$.get('<?php echo site_url('cart/reload_mini_cart'); ?>', function(mini_cart) {
				$("#cart").html(mini_cart);});
				// Display an info toast with no title
				toastr.success(' 1 '+ $('div#product_name'+id).text() + ' removed from cart');
				toastr.options.progressBar = true;  
                }
        });
        return false; 
    });
	
$('.add_item_from_mini_cart').click(function (e) {
        e.preventDefault();		
        var id = this.id; 
        $.ajax({
            type: "POST",
            data:'id='+id,
            url:'<?php echo site_url('cart/quick_add_to_cart'); ?>',
            success: function(respond)
                {
				$('div#product_cart'+id).show();
				$('div#product_cart'+id).text(Number($('div#product_cart'+id).text())+1);
				$.get('<?php echo site_url('cart/reload_menu'); ?>', function(cart) {
				$("#menu_div").html(cart);});
				$.get('<?php echo site_url('cart/reload_mini_cart'); ?>', function(mini_cart) {
				$("#cart").html(mini_cart);});
				// Display an info toast with no title
				toastr.success(' 1 '+ $('div#product_name'+id).text() + ' added to cart');
				toastr.options.progressBar = true; 
                }
        });
        return false; 
    });


$('.remove_item_from_mini_cart').click(function (e) {
        e.preventDefault();	
        var id = this.id; 
		if(Number($('div#product_qty_in_minicart'+id).text())>0) {	
        $.ajax({
            type: "POST",
            data:'id='+id,
            url:'<?php echo site_url('cart/removeitem_cart'); ?>',
            success: function(respond)
                {
				$('div#product_cart'+id).text(Number($('div#product_qty_in_minicart'+id).text())-1);
				
				if(Number($('div#product_cart'+id).text())>0)
				$('div#product_cart'+id).show();
				else
				$('div#product_cart'+id).hide();
				
				$.get('<?php echo site_url('cart/reload_menu'); ?>', function(cart) {
				$("#menu_div").html(cart);});
				$.get('<?php echo site_url('cart/reload_mini_cart'); ?>', function(mini_cart) {
				$("#cart").html(mini_cart);});				
				// Display an info toast with no title
				toastr.success(' 1 '+ $('div#product_name'+id).text() + ' removed from cart');
				toastr.options.progressBar = true; 
                }
        });
		}
        return false; 
    });

 });
</script>
<div id="cart" >
  <div class="content" style="max-height:450px;overflow:auto;">
    <div class="mini-cart-info">
      <table>
        <tbody>
          <?php
			$subtotal = 0;
			$index = 0; 
			foreach ($this->go_cart->contents() as $cartkey=>$product):?>
          <?php  
			$jsonString = $product['images'];			
			$arrayOfImages=(array)json_decode($jsonString);			
		 	$item_product->images    = array_values($arrayOfImages);
            			$index++;
                        if(!empty($item_product->images[0]))
                        {
                            $primary    = $item_product->images[0];
                            foreach($item_product->images as $photo)
                            {
                                if(isset($photo->primary))
                                {
                                    $primary    = $photo;
                                }
                            }

         $photo  = '<img height="50" width="50" src="'.base_url('uploads/images/small/'.$primary->filename).'" />';
                  }
         ?>
          <tr>
            <td class="image"><?php echo $photo; ?></td>
            <td><div><?php echo $product['name']; ?> </div>
              <div style="color:#999;font-size:15px;"><?php echo $product['weight'].'&nbsp;'.$product['unit'] ?></div>
              <div id="product_qty_in_minicart<?php echo $product['id']?>" style="display:none;"> <?php echo $product['quantity']; ?></div>
              <div><?php echo '&#8377;&nbsp;'.$product['saleprice'].'&nbsp;X &nbsp;'.$product['quantity'] .'&nbsp; = &nbsp;&#8377;&nbsp;'.($product['price']*$product['quantity']);?></div></td>
            <td><div id="<?php echo $product['id']?>" class="remove_item_from_mini_cart"> - </div><div id="<?php echo $product['id']?>" class="add_item_from_mini_cart"> + </div></td>
            <?php endforeach;?>
        </tbody>
      </table>
    </div>
    <div class="checkout"> <a href="<?php echo base_url();?>index.php/cart/view_cart" class="button"><span>View Cart</span></a> <a href="<?php echo base_url();?>index.php/checkout" class="button"><span>Checkout</span></a></div>
  </div>
</div>
<!--Cart Part End-->
