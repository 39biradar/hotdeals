<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div id="column-left">
      <div class="box">
        <div class="box-heading"><span>Information</span></div>
        <div class="box-content">
          <div class="box-category">
            <ul>
              <li><a href="<?php echo base_url();?>index.php/cart/about_us">About Us</a></li>
              <li><a href="<?php echo base_url();?>index.php/cart/contact_us">Contact Us</a></li>
              <li><a href="<?php echo base_url();?>index.php/cart/privacy_policy">Privacy Policy</a></li>
              <li><a href="<?php echo base_url();?>index.php/cart/terms_conditions">Terms &amp; Conditions</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div id="content">
      <div class="breadcrumb"> <a title="Home" href="index.html">Home</a> » <a title="About Us" href="about.html">Why Us?</a> </div>
      <h1><span>Why Us?</span></h1>
      <p> Committed to deliver fresh product at most competitive rate from local market.</p>
      <p>Hassle free delivery at your door step.</p>
      <p> Team of experienced market hunters, procuring goods as per your daily needs.</p>
      <p>We are evolving and ready to accept your suggestions and feedbacks to serve you better.</p>
      <p>Delivery Branches nearer to your location, Gurgaon All Sectors, and expanding for more locations sooner.</p>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
</div>
</div>
