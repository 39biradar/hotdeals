<style>#search {display:none;}</style>

<?php
$first		= array('id'=>'bill_firstname', 'class'=>'span3', 'name'=>'firstname', 'value'=> set_value('firstname'));
$last		= array('id'=>'bill_lastname', 'class'=>'span3', 'name'=>'lastname', 'value'=> set_value('lastname'));
$email		= array('id'=>'bill_email', 'class'=>'span3', 'name'=>'email', 'value'=>set_value('email'));
$phone		= array('id'=>'bill_phone', 'class'=>'span3', 'name'=>'phone', 'value'=> set_value('phone'));
?>
<div class="wrapper">
    <div id="notification"></div>
    <div id="container">
      <div id="content">
<div style="margin:50px 0px;">
<table class="form" style="margin:0 auto;width: auto;!important;">
  <tbody>
	
		<tr><td><h1><?php echo lang('form_register');?></h1></td></tr>
			
		
		<?php echo form_open('secure/register'); ?>
			<input type="hidden" name="submitted" value="submitted" />
			<input type="hidden" name="redirect" value="<?php echo $redirect; ?>" />

			<fieldset>
				<tr><td>
						<label for="account_firstname"><?php echo lang('account_firstname');?></label>
						<?php echo form_input($first);?>
					</td></tr>
				<tr><td>
						<label for="account_lastname"><?php echo lang('account_lastname');?></label>
						<?php echo form_input($last);?>
					</td></tr>
			
				<tr><td>
						<label for="account_email"><?php echo lang('account_email');?></label>
						<?php echo form_input($email);?>
					</td></tr>
				
					<tr><td>
						<label for="account_phone"><?php echo lang('account_phone');?></label>
						<?php echo form_input($phone);?>
					</td></tr>
			
				
			<tr><td>
						<label for="account_password"><?php echo lang('account_password');?></label>
						<input type="password" name="password" value="" class="span3" autocomplete="off" />
				</td></tr>

					<tr><td>
						<label for="account_confirm"><?php echo lang('account_confirm');?></label>
						<input type="password" name="confirm" value="" class="span3" autocomplete="off" />
					</td></tr>
					
					<tr><td>
						<label class="checkbox">
							<input type="checkbox"  name="email_subscribe" value="1" <?php echo set_radio('email_subscribe', '1', FALSE); ?>/> <?php echo lang('account_newsletter_subscribe');?>
						</label>
					</td></tr>
				
				<tr><td><input type="submit" value="<?php echo lang('form_register');?>" id="submit" />
				<span style="margin-left: 10px;"><a href="<?php echo site_url('secure/login'); ?>"><?php echo lang('go_to_login');?></span></a></td>
				</tr>
			</fieldset>
		</form>
	
	</tbody></table>
</div>

      </div>
      <div class="clear"></div>
    </div>
  </div>