<style>#search {display:none;}</style>
<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div id="column-left">
      <div class="box">
        <div class="box-heading"><span>Information</span></div>
        <div class="box-content">
          <div class="box-category">
            <ul>
              <li><a href="<?php echo base_url();?>index.php/cart/about_us">About Us</a></li>
              <li><a href="<?php echo base_url();?>index.php/cart/contact_us">Contact Us</a></li>
              <li><a href="<?php echo base_url();?>index.php/cart/privacy_policy">Privacy Policy</a></li>
              <li><a href="<?php echo base_url();?>index.php/cart/terms_conditions">Terms &amp; Conditions</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div id="content">
      <div class="breadcrumb"> <a title="Home" href="index.html">Home</a>  >> <a title="Your Feedback" href="<?php echo base_url();?>cart/feedback">Your Feedback</a> </div>
      <h1><span>Your Feedback </span></h1>
      <div id="notification"></div>
      <?php if (isset($message)) :?>
      <div class="alert alert-info"> <a class="close" data-dismiss="alert">x</a> <?php echo $message;?> </div>
      <?php endif;?>
      <table class="form" style="margin:0 auto;width: auto;!important;">
        <tbody>
        <fieldset>
        <?php echo form_open('secure/contact_sendmail'); ?>
        <tr>
          <td><input type="text" placeholder="Your name" name="name" id="name" />
        <tr>
          <td>
        <tr>
          <td><input type="text" placeholder="Your email" name="email" id="email" />
        <tr>
          <td>
        <tr>
          <td><input type="text" placeholder="Your phone number" name="phone"  id="phone" />
        <tr>
          <td>
        <tr>
          <td><textarea placeholder="Your message" name="comments" id="comments"></textarea>
        <tr>
          <td>
        <tr>
          <td><input type="submit"  id="submit"  value="Send message" />
        <tr>
          <td></form>
        </fieldset>
        </tbody>
      </table>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
</div>
</div>
