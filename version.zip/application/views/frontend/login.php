<style>#search {display:none;}</style>
<div class="wrapper">
    <div id="notification"></div>
    <div id="container">
      <div id="content">
      
            <?php if (validation_errors()):?>
	<div class="alert alert-error">
		<a class="close" data-dismiss="alert">×</a>
		<?php echo validation_errors();?>
	</div>
<?php endif;?>
<div  style="margin-top:50px;">
<table class="form" style="margin:0 auto;width: auto;!important;">
  <tbody>
	
		<tr><td><h1><?php echo lang('login');?></h1></td></tr>		
			<?php echo form_open('secure/login', 'class="form-horizontal"'); ?>
				<fieldset>				
					<tr><td>
						<label class="control-label" for="email"><?php echo lang('email');?></label>
						</td></tr>
						<tr><td>
						<div class="controls">
							<input type="text" name="email" value=""  class="span3"/>
						</div>
					</td></tr>
				
					<tr><td>
						<label class="control-label" for="password"><?php echo lang('password');?></label>
						</td></tr>
						<tr><td>
						<div class="controls">
							<input type="password" name="password" class="span3" autocomplete="off" />
						</div>
					</td></tr>
				
					<tr><td>
						<label class="control-label"></label>
						<div class="controls">
							<label class="checkbox">
								<input name="remember" value="true" type="checkbox" />
								 <?php echo lang('keep_me_logged_in');?>
							</label>
						</div>
					</td></tr>
					<tr><td>
						<label class="control-label" for="password"></label>
						<div class="controls">
							<input  id="submit" type="submit" value="<?php echo lang('form_login');?>" name="submit" />
						</div>
					</td></tr>
				</fieldset>
				
				<input type="hidden" value="<?php echo $redirect; ?>" name="redirect"/>
				<input type="hidden" value="submitted" name="submitted"/>
				
			</form>
		
			<tr><td>
				<a href="<?php echo site_url('secure/forgot_password'); ?>"><?php echo lang('forgot_password')?></a> | <a href="<?php echo site_url('secure/register'); ?>"><?php echo lang('register');?></a>
			<tr><td>
	
	</tbody></table>
</div>

      </div>
      <div class="clear"></div>
    </div>
  </div>