<!-- header starts here -->
<script src="<?php echo base_url();?>assets/js/custom.js"></script>
<script>
    window.onload = function()
    {
        $('.product').equalHeights();
    }
</script>
<script type="text/javascript"> 
jQuery(document).ready(function(){
$('.btn_addcart_popup').click(function (e) {
        e.preventDefault();
		var qty = $("#qty").val();	
        var id = this.id; 
        $.ajax({
            type: "POST",
            data:{ 'id': id , 'qty': qty},
            url:'<?php echo site_url('cart/quick_add_to_cart'); ?>',
            success: function(respond)
                {
				$('div#product_cart'+id).show();
				$('div#product_cart'+id).text(Number($('div#product_cart'+id).text())+ Number(qty));
				$.get('<?php echo site_url('cart/reload_menu'); ?>', function(cart) {
				$("#menu_div").html(cart);});
				$.get('<?php echo site_url('cart/reload_mini_cart'); ?>', function(mini_cart) {
				$("#cart").html(mini_cart);});
				// Display an info toast with no title
				toastr.success(qty +' '+ $('div#product_name'+id).text() + ' added to cart');
				toastr.options.progressBar = true; 
                }
        });
        return false; 
    });
	
	
 $('.product_option_anchor').click(function (e) {
        e.preventDefault();
        var id = this.id; 
		var total_option_count  = $('#total_options'+id).val();
		var product_id 		    = $('#product_id'+id).val();
		var product_wieght      = $('#product_wieght'+id).val();
		var product_saleprice   = $('#product_saleprice'+id).val();
		var product_price       = $('#product_price'+id).val();
		for( var i = 0; i<total_option_count;  i++) {
		if(i==id)
		$('#option'+i).attr('class', 'model_pop_options_active');
		else
		$('#option'+i).attr('class', 'model_pop_options_inactive');			
		}
		$('#selected_weight').text(product_wieght);
		var price = '<span class="sprice">'+ product_saleprice + '</span> <span class="mrpprice">MRP &nbsp;'+ product_price+'</span>';
		$('#selected_price').text('');
		$('#selected_price').html(price);
		$('.btn_addcart_popup').attr('id', product_id);	
		
		
		
		
    });

 });
</script>
<?php   $product->images    = array_values($product->images);
            			
                        if(!empty($product->images[0]))
                        {
                            $primary    = $product->images[0];
                            foreach($product->images as $photo)
                            {
                                if(isset($photo->primary))
                                {
                                    $primary    = $photo;
                                }
                            }
                         $photo  = '<img style="display: inline-block;" width="200" height="260"  src="'.base_url('uploads/images/full/'.$primary->filename).'" alt="'.$product->seo_title.'"/>';
                        }
                        ?>

<div style="background:#fff;height:350px;width:550px;">
  <div class="model_pop_up_left_section"> <?php echo $photo;?> </div>
  <div class="model_pop_up_right_section">
  
    <div id="tab<?php echo $product->id; ?>" >
    <div class="model_pop_up_product_name"><?php echo $product->name ?></div>
    <div id="selected_weight" class="model_pop_up_weight"><?php echo $product->weight.'&nbsp;'.$product->unit; ?></div>
    <div id="selected_price" class="model_pop_up_weight"><span class="sprice">&#8377;&nbsp;<?php echo $product->saleprice;?></span> <span class="mrpprice">MRP &nbsp; &#8377;&nbsp;<?php echo $product->price;?></span></div>
   <div class="model_pop_up_qty">Quantity :<span class="qty"> <a class="qtyBtn mines" href="javascript:void(0);">- </a></span>
      <input id="qty" type="text" class="w30" name="quantity" size="2" value="1">
      <span class="qty"><a class="qtyBtn plus" href="javascript:void(0);"> + </a> </span> </div>
      <?php if(!empty($product->related_products)):?>
    <div style="height:60px;width:98%;"> <?php $count=0; foreach($product->related_products as $more_option):?>  
    <!-- pass the parameters in the id to update -->
    <input id="total_options<?php echo $count;?>" type="hidden" name="total_options"  value="<?php echo count($product->related_products);?>">
    <input id="product_id<?php echo $count;?>" type="hidden" name="product_id" value="<?php echo $more_option->id;?>">
    <input id="product_wieght<?php echo $count;?>" type="hidden" name="product_wieght" value="<?php echo $more_option->weight.'&nbsp;'.$more_option->unit;?>">
    <input id="product_saleprice<?php echo $count;?>" type="hidden" name="product_saleprice" value="<?php echo '&#8377;&nbsp;'.$more_option->saleprice;?>">
    <input id="product_price<?php echo $count;?>" type="hidden" name="product_price" value="<?php echo '&#8377;&nbsp;'.$more_option->price;?>">
    <a class="product_option_anchor" id="<?php echo $count;?>"> 
    <?php if($count==0): $option_class = 'model_pop_options_active'; else : $option_class = 'model_pop_options_inactive'; endif; ?>  
    <span  id="option<?php echo $count;?>" class="<?php echo $option_class?>"> <?php echo $more_option->weight.'&nbsp;'.$more_option->unit; ?> <br />&#8377;&nbsp;<?php echo $more_option->saleprice;?></span>  </a> 
    <?php $count++; endforeach;?>
    </div> 
    <?php endif; ?>  
    <div class="model_pop_up_product_addtocart"> <a id="<?php echo $product->id ?>" href="#s" class="btn_addcart_popup button"><span>Add to Cart</span></a> </div>
    </div>
     
  </div>
</div>


