<style>#search {display:none;}</style>
<div class="wrapper">
    <div id="notification"></div>
    <div id="container">

<div id="column-left" style="margin-top:100px;padding-left:10px;">
    <div class="box">
  <div class="box-heading"><span>Information</span></div>
  <div class="box-content">
  <div class="box-category">
    <ul>
             <li><a href="<?php echo base_url();?>index.php/cart/about_us">About Us</a></li>
            <li><a href="<?php echo base_url();?>index.php/cart/contact_us">Contact Us</a></li>
            <li><a href="<?php echo base_url();?>index.php/cart/privacy_policy">Privacy Policy</a></li>
            <li><a href="<?php echo base_url();?>index.php/cart/terms_conditions">Terms &amp; Conditions</a></li>
     
    </ul>
    </div>
  </div>
</div>
  </div>
 
<div id="content" style="padding-top:100px;padding-right:20px;">		 
  
  
  <h1><span>About Us</span></h1>
  <p>The Sabzitime Shop is a family owned, online grocery shop delivering quality fresh produce and local products straight to the doors of local families. The Sabzitime Shop has been servicing local households since 2003. Our main objective and the reason behind our service is to help the local farmer supply their product to the people of Gurgaon, and to provide convenience and quality produce to our customers.



Produce is brought back from the markets to our refrigerated packing rooms where our dedicated team fill the orders for the day.  That same afternoon, our driver delivers orders in a refrigerated truck direct to our customers' doors. We don't warehouse stock, we buy produce to order so our stock does not sit around for days waiting to be purchased.</p>
  
  <p>Early every morning, John visits the Canning Vale Markets and selects the freshest and the best quality fruit and vegies that are on offer by local farmers. Produce is picked and brought to the markets by growers the night before or early that same morning, packed and delivered direct to you.</p>
  
  </div>
<div class="clear"></div>


</div>
      <div class="clear"></div>
    </div>
  </div>