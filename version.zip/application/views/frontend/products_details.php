<style>
ul.thumbnails {padding:0px; margin:0px; list-style:none; *zoom:1;}
.thumbnails > li {float: left; margin: 0 20px 25px 0px;}
.thumbnail { display:block; padding:0; line-height:1; border:1px solid #d7d7d7; border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px; -o-border-radius:3px; -ms-border-radius:3px; }
a.thumbnail:hover { border-color:#a6a6a6; }
.main_thumb > img { display:block; max-width:100%;  margin-left:auto; margin-right:auto; }
.thumbnail > img { display:block; max-width:100%; margin-left:auto; margin-right:auto; }
.thumbnail .caption { padding:9px; }
.smlThumb { width:auto; }
.span2 { width:80px; float:left; margin:0 24px 10px 0; }
.span4 { width:300px; }
.span6 { width:320px; float:left; }
.row {margin-left:0px; *zoom: 1; }
.zfr { float:right!important; margin:0 0 25px 0!important; }
.imgadli { margin:-30px 0 0px 0!important; }
.row:before,
.row:after { display:table; content:""; }
.row:after { clear:both; }
.cloud-zoom-big {border:none; overflow:hidden; margin:5px 0 0 -9px;}
.right { float:right; width:635px; }
#wrap {  }
.mousetrap { cursor:move!important; }
#wrap > a:hover, .span2 a:hover { border:solid 1px #a6a6a6; }
h1 { display:none; visibility:hidden; }
.thubs {overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: 0px; width: 98%;}

@media screen and (min-width:0px) and (max-width:760px) {
.thumbnails > li.span4 { float:none; margin:0 auto; text-align:center; }
ul.thumbnails {padding:0px; margin:0px auto; list-style:none; *zoom:1;}
.thumbnails > li {float:none; margin:0 0 25px 0;}
.right {width:auto;margin-top:10px;  }
.smlThumb { text-align:center;}

.span2 { width:80px; float:none; margin:5px 24px 10px 0; display:inline-block; }
.jcarousel-skin-opencart .jcarousel-container {margin-top: 20px;}
.product-info > .span6 {text-align: center;}
.thubs {width: 50%;min-width:350px;margin:0 auto;}
}
</style>
<script>
    window.onload = function()
    {
        $('.product').equalHeights();
    }
</script>
<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div id="content">
      <div class="breadcrumb">
        <?php
						$url_path	= '';
						$count	 	= 1;
						$url_path .= '/'; ?>
        <a href="<?php echo site_url($url_path);?>"><?php echo 'Home'; ?></a> »
        <?php foreach($base_url as $bc):
							$url_path .= '/'.$bc;
							?>
        <?php if($count == count($base_url)):?>
        <a href="#"><?php echo $bc; ?></a>
        <?php else:?>
        <a href="<?php echo site_url($url_path);?>"><?php echo $bc;?></a> »
        <?php endif;
							$count++;
						endforeach;?>
      </div>
      <?php   $product->images    = array_values($product->images);
            			
                        if(!empty($product->images[0]))
                        {
                            $primary    = $product->images[0];
                            foreach($product->images as $photo)
                            {
                                if(isset($photo->primary))
                                {
                                    $primary    = $photo;
                                }
                            }
                         $photo  = '<img style="max-height:90%;max-width:90%; position: absolute;margin: auto;top: 0;left: 0;right: 0;bottom: 0;"  src="'.base_url('uploads/images/full/'.$primary->filename).'" alt="'.$product->seo_title.'"/>';
                        }
                        ?>
      <div class="product-info">
        <div class="span6" style="margin-left: 0px;">
          <ul class="thumbnails row">
            <li class="span4">
              <div id="wrap" style="top:0px;z-index:9999;position:relative;"><a href="#a" title=""  class="cloud-zoom jackbox thumbnail" data-group="images"  rel=" style="position: relative; display: block;">
                <div id="primary-img" style="min-height:336px;max-height:100%;max-width: 100%;"> <?php echo $photo;?> </div>
                </a></div>
            </li>
            <?php if(count($product->images) > 1):?>
            <li class="imgadli">
              <div class="image-additional">
                <div id="carousel94">
                  <div class=" jcarousel-skin-opencart">
                    <div class="jcarousel-container jcarousel-container-horizontal" style="position: relative; display: block;margin-top: 20px;">
                      <div class="jcarousel-clip jcarousel-clip-horizontal" style="position: relative;">
                        <div class="jcarousel-container jcarousel-container-horizontal" style="position: relative; display: block;">
                          <ul class="jcarousel-list jcarousel-list-horizontal thubs" >
                            <?php foreach($product->images as $image):?>
                            <li class="jcarousel-item jcarousel-item-horizontal jcarousel-item-1 jcarousel-item-1-horizontal" jcarouselindex="1" style="float: left; list-style: none; width: 70px;"> <a href="#a" title="" class="thumbnail" data-group="images"  data-thumbnail="<?php echo base_url('uploads/images/full/'.$image->filename);?>"> <img class="span1"   onclick="$(this).squard('336', $('#primary-img'));" src="<?php echo base_url('uploads/images/full/'.$image->filename);?>"/> </a> </li>
                            <?php endforeach;?>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <?php endif;?>
          </ul>
        </div>
        <div class="right" style="border:1px solid #d7d7d7; border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px; -o-border-radius:3px; -ms-border-radius:3px;">
          <h1><span>Canon EOS 5D</span></h1>
          <div id="tab-information" class="tab-content" style="display: block;">
            <!--Price Start-->
            <div class="price">
              <div class="prDetailMain"> <span class="textPrice">Price:</span> <span class="price-old"><?php echo $product->price ?></span> <span class="cyan_price price-new"><span> <?php echo $product->currency.'&nbsp;'.$product->saleprice.'&nbsp;/'.$product->unit; ?></span></span> <br>
              </div>
            </div>
            <!--Price End-->
            <div class="description">
              <div class="prDetailMain">
                <h2><?php echo $product->name ?></h2>
                <span>Availability:</span>
                <?php if($product->track_stock == 1):?>
                In Stock
                <?php else: ?>
                Not Available
                <?php endif; ?>
                <br>
                <span>Product Description :</span> <?php echo $product->description ?>
                <span><strong>Delivery Available Only at:</strong></span> <a >
				 <?php $count=0;$areas='';  
				 foreach($delivery_areas as $delivery_area):
				 
				 			$count++;
							if($count==sizeof($delivery_areas))
                            $areas.= $delivery_area->locality_name;
							else
							$areas.= $delivery_area->locality_name.',';
                            ?>
				<?php endforeach; ?> <strong><?php echo $areas;  ?></strong>
				
				</a><br><br>
                <div class="row">
                  <div class="span8">
                    <div class="product-cart-form"> <?php echo form_open('cart/add_to_cart', 'class="form-horizontal"');?>
                      <input type="hidden" name="cartkey" value="<?php echo $this->session->flashdata('cartkey');?>" />
                      <input type="hidden" name="id" value="<?php echo $product->id?>"/>
                      <fieldset>
                      <?php if(count($options) > 0): ?>
                      <?php foreach($options as $option):
                            $required   = '';
                            if($option->required)
                            {
                                $required = ' <p class="help-block">Required</p>';
                            }
                            ?>
                      <div class="control-group">
                        <label class="control-label"><?php echo $option->name;?></label>
                        <?php
                                /*
                                this is where we generate the options and either use default values, or previously posted variables
                                that we either returned for errors, or in some other releases of Go Cart the user may be editing
                                and entry in their cart.
                                */

                                //if we're dealing with a textfield or text area, grab the option value and store it in value
                                if($option->type == 'checklist')
                                {
                                    $value  = array();
                                    if($posted_options && isset($posted_options[$option->id]))
                                    {
                                        $value  = $posted_options[$option->id];
                                    }
                                }
                                else
                                {
                                    if(isset($option->values[0]))
                                    {
                                        $value  = $option->values[0]->value;
                                        if($posted_options && isset($posted_options[$option->id]))
                                        {
                                            $value  = $posted_options[$option->id];
                                        }
                                    }
                                    else
                                    {
                                        $value = false;
                                    }
                                }

                                if($option->type == 'textfield'):?>
                        <div class="controls">
                          <input type="text" name="option[<?php echo $option->id;?>]" value="<?php echo $value;?>" class="span4"/>
                          <?php echo $required;?> </div>
                        <?php elseif($option->type == 'textarea'):?>
                        <div class="controls">
                          <textarea class="span4" name="option[<?php echo $option->id;?>]"><?php echo $value;?></textarea>
                          <?php echo $required;?> </div>
                        <?php elseif($option->type == 'droplist'):?>
                        <div class="controls">
                          <select name="option[<?php echo $option->id;?>]">
                           
                            <?php foreach ($option->values as $values):
                                            $selected   = '';
                                            if($value == $values->id)
                                            {
                                                $selected   = ' selected="selected"';
                                            }?>
                            <option<?php echo $selected;?> value="<?php echo $values->id;?>"> <?php echo $values->name.$product->unit. "&nbsp;&nbsp;&nbsp;".$product->currency.'&nbsp;&nbsp;'.$values->price; ?> </option>
                            <?php endforeach;?>
                          </select>
                          <?php echo $required;?> </div>
                        <?php elseif($option->type == 'radiolist'):?>
                        <div class="controls">
                          <?php foreach ($option->values as $values):

                                            $checked = '';
                                            if($value == $values->id)
                                            {
                                                $checked = ' checked="checked"';
                                            }?>
                          <label class="radio">
                          <input<?php echo $checked;?> type="radio" name="option[<?php echo $option->id;?>]" value="<?php echo $values->id;?>"/>
                          <?php echo($values->price != 0)?'(+'.($values->price).') ':''; echo $values->name;?> </label>
                          <?php endforeach;?>
                          <?php echo $required;?> </div>
                        <?php elseif($option->type == 'checklist'):?>
                        <div class="controls">
                          <?php foreach ($option->values as $values):

                                            $checked = '';
                                            if(in_array($values->id, $value))
                                            {
                                                $checked = ' checked="checked"';
                                            }?>
                          <label class="checkbox">
                          <input<?php echo $checked;?> type="checkbox" name="option[<?php echo $option->id;?>][]" value="<?php echo $values->id;?>"/>
                          <?php echo($values->price != 0)?'('.($values->price).') ':''; echo $values->name;?> </label>
                          <?php endforeach; ?>
                        </div>
                        <?php echo $required;?>
                        <?php endif;?>
                      </div>
                      <?php endforeach;?>
                      <?php endif;?>
                      <div style="margin-top:10px;margin-bottom:10px;">
                        <?php if(!config_item('inventory_enabled') || config_item('allow_os_purchase') || !(bool)$product->track_stock || $product->quantity > 0) : ?>
                        <div>
                          <div class="qty"> <span class="qtytxt">Qty : <a class="qtyBtn mines" href="javascript:void(0);">-</a>
                            <input id="qty" type="text" class="w30" name="quantity" size="2" value="1">
                            <a class="qtyBtn plus" href="javascript:void(0);">+</a>
                            <input type="hidden" name="product_id" size="2" value="30">
                            </span></div>
                          <input  id="submit"  type="submit" value="<?php echo lang('form_add_to_cart');?>">
                          </input >
                        </div>
                        <?php endif;?>
                      </div>
                      </fieldset>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!--related products-->
    <?php if(!empty($product->related_products)):?>
    <div class="related_products">
        <div class="row">
                <h4 style="margin-top:20px;"><?php echo lang('related_products_title');?></h4>
                <ul class="thumbnails"> 
                <?php foreach($product->related_products as $relate):?>
                    <li style="height: 250px;width: 150px;">
                        <?php
                        $photo  = theme_img('no_picture.png', lang('no_image_available'));
                        
                        
                        
                        $relate->images = array_values((array)json_decode($relate->images));
                        
                        if(!empty($relate->images[0]))
                        {
                            $primary    = $relate->images[0];
                            foreach($relate->images as $photo)
                            {
                                if(isset($photo->primary))
                                {
                                    $primary    = $photo;
                                }
                            }

                            $photo  = '<img style="height:150px;width: 150px;" src="'.base_url('uploads/images/thumbnails/'.$primary->filename).'" alt="'.$relate->seo_title.'"/>';
                        }
                        ?>
                        <a class="thumbnail" href="<?php echo site_url($relate->slug); ?>">
                            <?php echo $photo; ?>
                        </a>
                        <h4 style="margin-top:5px;"><a href="<?php echo site_url($relate->slug); ?>"><?php echo $relate->name;?></a>
                        <?php if($this->session->userdata('admin')): ?>
                        <a class="btn" title="<?php echo lang('edit_product'); ?>" href="<?php echo  site_url($this->config->item('admin_folder').'/products/form/'.$relate->id); ?>"><i class="icon-pencil"></i></a>
                        <?php endif; ?>
                        </h4>

                        <div>
                            <?php if($relate->saleprice > 0):?>
                                <span style="text-decoration:line-through ;font-size:.9em;color:#999;"><?php echo lang('product_reg');?> <?php echo $relate->price; ?></span>
                                <span class="price-sale"><?php echo lang('product_sale');?> <?php echo $relate->saleprice; ?></span>
                            <?php else: ?>
                                <span class="price-reg"><?php echo lang('product_price');?> <?php echo $relate->price; ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if((bool)$relate->track_stock && $relate->quantity < 1 && config_item('inventory_enabled')) { ?>
                            <div class="stock_msg"><?php echo lang('out_of_stock');?></div>
                        <?php } ?>
                    </li>
                <?php endforeach;?>
                </ul>
        </div>
    </div>
    <?php endif;?>   
  </div>
</div>
<div class="clear"></div>
