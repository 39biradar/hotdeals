<script type="text/javascript"> 
jQuery(document).ready(function(){
	jQuery('#carouselfeature li').hover(function(){
		jQuery(this).find('#addcart_div').show();
	},function(){
		jQuery(this).find('#addcart_div').hide();
	});
	
 });
</script>
<script type="text/javascript"> 
jQuery(document).ready(function(){
$('.btn_addcart').click(function (e) {
        e.preventDefault();	
        var id = this.id; 
		var qty = 1;
        $.ajax({
            type: "POST",
            data:{ 'id': id , 'qty': qty},
            url:'<?php echo site_url('cart/quick_add_to_cart'); ?>',
            success: function(respond)
                {
				$('div#product_cart'+id).show();
				$('div#product_cart'+id).text(Number($('div#product_cart'+id).text())+ Number(qty));
				$.get('<?php echo site_url('cart/reload_menu'); ?>', function(cart) {
				$("#menu_div").html(cart);});
				$.get('<?php echo site_url('cart/reload_mini_cart'); ?>', function(mini_cart) {
				$("#cart").html(mini_cart);});
				// Display an info toast with no title
				toastr.success( qty +' '+ $('div#product_name'+id).text() + ' added to cart');
				toastr.options.progressBar = true; 
                }
        });
        return false; 
    });


$('.btn_removecart,.remove_item_from_mini_cart').click(function (e) {
        e.preventDefault();	
        var id = this.id; 
		if(Number($('div#product_qty_in_minicart'+id).text())>0) {	
        $.ajax({
            type: "POST",
            data:'id='+id,
            url:'<?php echo site_url('cart/removeitem_cart'); ?>',
            success: function(respond)
                {
				$('div#product_cart'+id).text(Number($('div#product_qty_in_minicart'+id).text())-1);
				
				if(Number($('div#product_cart'+id).text())>0)
				$('div#product_cart'+id).show();
				else
				$('div#product_cart'+id).hide();
				
				$.get('<?php echo site_url('cart/reload_menu'); ?>', function(cart) {
				$("#menu_div").html(cart);});
				$.get('<?php echo site_url('cart/reload_mini_cart'); ?>', function(mini_cart) {
				$("#cart").html(mini_cart);});				
				// Display an info toast with no title
				toastr.success(' 1 '+ $('div#product_name'+id).text() + ' removed from cart');
				toastr.options.progressBar = true; 
                }
        });
		}
        return false; 
    });

$('.show_details_modal').click(function (e) {
        e.preventDefault();		
		var id = this.id; 	
        $.ajax({
            type: "POST",
			data:'id='+id,
            url:'<?php echo site_url('cart/product'); ?>',
            success: function(data)
            {	
			$('#product-container').html(data);
			$('#modal-text').flythat('show');			
            }
        });
		
        return false; 
    });


$('.more_options').click(function (e) {
        e.preventDefault();		
		var id = this.id; 	
        $.ajax({
            type: "POST",
			data:'id='+id,
            url:'<?php echo site_url('cart/more_product'); ?>',
            success: function(data)
            {	
			$('#product-container').html(data);
			$('#modal-text').flythat('show');			
            }
        });
		
        return false; 
    });

	//create the modal
$('#modal-text').flythat({
    show: false
});

 });
</script>

<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div id="content" style="background:#f1f2f3;">
      <div  style="width:100%;height:50px;text-align:center;padding-top:10px;"> <span style="color:#0fbe7c;font-size:18px;"> Free shipping on orders over &nbsp;&#8377;&nbsp;200 </span> </div>
      <div id="left_side_bar">
        <div class="column_category">
          <?php foreach ($related_category as $cat):?>
          <h7>
            <?= ucwords(strtolower($cat['name']));?>
          </h7>
          <ul>
            <?php if(isset($cat['sub_categories'])):?>
            <?php foreach($cat['sub_categories'] as $sub_category):?>
            <li><a href="<?php echo site_url($sub_category['slug']);?>">
              <?=$sub_category['name'];?>
              </a></li>
            <?php endforeach;?>
            <?php endif;?>
          </ul>
          <?php endforeach;?>
        </div>
      </div>
      <div id="right_side_bar">
        <div class="box">
          <div class="box-content">
            <div class="elastislide-wrapper elastislide-horizontal">
              <div class="elastislide-carousel">
                <ul class="elastislide-list customcarousel product_cell" id="carouselfeature" >
                  <?php $index = 0; ?>
                  <?php  foreach($products as $product){ ?>
                  <?php   $product->images    = array_values($product->images);
            			$index++;
                        if(!empty($product->images[0]))
                        {
                            $primary    = $product->images[0];
                            foreach($product->images as $photo)
                            {
                                if(isset($photo->primary))
                                {
                                    $primary    = $photo;
                                }
                            }

                           $photo  = '<img height="165" width="170" src="'.base_url('uploads/images/small/'.$primary->filename).'" alt="'.$product->seo_title.'"/>';
                        }
                        ?>
                  <?php
        $item ="" ;
        if($index % 5 == 1)
        {
            $item ="first";
        }
        else if($index % 5 == 0)
        {
            $item ="last";
        }
        else
        {
            $item ="";
        }
    ?>
                  <li class="<?php echo $item;?>" style="position:relative;">
                    <!--check if current product is in cart-->
                    <?php $quantityincart = 0; $display = 'none'; if ($this->go_cart->total_items()>0) :
                foreach ($this->go_cart->contents() as $cartkey=>$cartproduct):
                if( $cartproduct['id']== $product->id) : ?>
                    <?php  $quantityincart = $cartproduct['quantity'];  $display = 'block'; break;?>
                    <?php endif;?>
                    <?php endforeach;?>
                    <?php endif;?>
                    <div id="product_cart<?php echo $product->id?>" class="con-text" style='display:<?= $display ?>'><?php echo $quantityincart; ?></div>
                    <div class="inner">
                      <div id="addcart_div" style="height:35px;"><span id="<?php echo $product->id?>" class="btn_removecart"> - </span> <span id="<?php echo $product->id?>" class="btn_addcart"> + </span></div>
                      <div class="image"><a class="show_details_modal" id="<?php echo $product->id?>"  href="#s"><?php echo $photo;?> </a> </div>
                      <div id="product_name<?php echo $product->id?>" class="name"><a href ="#s"><?php echo $product->name; ?></a></div>
                      <div  id="product_qty<?php echo $product->id?>" class="price weight" >  <?php echo $product->weight.'&nbsp;'.$product->unit; ?> <?php if(!empty($product->related_products)) :?> <span id="more_option#<?php echo $product->id?>"  class="more_options"> <a href="#s"> More Options</a> </span> <?php endif;?> </div>
                      <div class="price"><span class="sprice">&#8377;&nbsp;<?php echo $product->saleprice;?></span> <span class="mrpprice">MRP &nbsp; &#8377;&nbsp;<?php echo $product->price;?></span></div>
                      <input type="hidden" name="cartkey" value="<?php echo $this->session->flashdata('cartkey');?>" />
                      <input type="hidden" name="id" value="<?php echo $product->slug?>"/>
                    </div>
                  </li>
                  <?php } ?>
                </ul>
              </div>
            </div>
            <div class="flythat" data-autoOpen="false" id="modal-text"> <a href="#close" class="close flythat-close">&times;</a>
              <div class="text-fly" id="product-container">
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
