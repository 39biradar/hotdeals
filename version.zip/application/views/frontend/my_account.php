<style>#search {display:none;}</style>
<div class="wrapper">
    <div id="notification"></div>
    <div id="container">
      <div id="content">
<?php if(validation_errors()):?>
<div class="alert allert-error">
	<a class="close" data-dismiss="alert">×</a>
	<?php echo validation_errors();?>
</div>
<?php endif;?>
<script type="text/javascript">
$(document).ready(function(){
	$('.delete_address').click(function(){
		if($('.delete_address').length > 1)
		{
			if(confirm('<?php echo lang('delete_address_confirmation');?>'))
			{
				$.post("<?php echo site_url('secure/delete_address');?>", { id: $(this).attr('rel') },
					function(data){
						$('#address_'+data).remove();
						$('#address_list .my_account_address').removeClass('address_bg');
						$('#address_list .my_account_address:even').addClass('address_bg');
					});
			}
		}
		else
		{
			alert('<?php echo lang('error_must_have_address');?>');
		}	
	});
	
	$('.edit_address').click(function(){
		$.post('<?php echo site_url('secure/address_form'); ?>/'+$(this).attr('rel'),
			function(data){				
			$('#product-container').html(data);
			$('#modal-text').flythat('show');
			}
		);
	});
	
	//create the modal
$('#modal-text').flythat({
    show: false
});
	
	
});


function set_default(address_id, type)
{
	$.post('<?php echo site_url('secure/set_default_address') ?>/',{id:address_id, type:type});
}
</script>
<style>
table.form td {padding: 3px !important;}
.table-bordered th, .table-bordered td {padding: 0px !important;}
</style>

<?php
$company	= array('id'=>'company', 'class'=>'span4', 'name'=>'company', 'value'=> set_value('company', $customer['company']));
$first		= array('id'=>'firstname', 'class'=>'span2', 'name'=>'firstname', 'value'=> set_value('firstname', $customer['firstname']));
$last		= array('id'=>'lastname', 'class'=>'span2', 'name'=>'lastname', 'value'=> set_value('lastname', $customer['lastname']));
$email		= array('id'=>'email', 'class'=>'span2', 'name'=>'email', 'value'=> set_value('email', $customer['email']));
$phone		= array('id'=>'phone', 'class'=>'span2', 'name'=>'phone', 'value'=> set_value('phone', $customer['phone']));
$password	= array('id'=>'password', 'class'=>'span2', 'name'=>'password', 'value'=>'');
$confirm	= array('id'=>'confirm', 'class'=>'span2', 'name'=>'confirm', 'value'=>'');
?>	
<div style="width: 100%">
<div class="span4" style="float: left;margin:20px 0px;">
	<div class="my-account-box">
	 <table class="form" style="margin:0 auto;width: 90%;!important;">
  		<tbody>
		<?php echo form_open('secure/my_account'); ?>
			<fieldset>
				<h4><?php echo lang('account_information');?></h4>
				<tr><td>	
						<label for="account_firstname"><?php echo lang('account_firstname');?></label>
						<?php echo form_input($first);?>
					</td></tr>
				
					<tr><td>
						<label for="account_lastname"><?php echo lang('account_lastname');?></label>
						<?php echo form_input($last);?>
					</td></tr>
			
				<tr><td>
						<label for="account_email"><?php echo lang('account_email');?></label>
						<?php echo form_input($email);?>
					</td></tr>
				
					<tr><td>
						<label for="account_phone"><?php echo lang('account_phone');?></label>
						<?php echo form_input($phone);?>
					</td></tr>
			
				<tr><td>
						<label class="checkbox">
							<input type="checkbox" name="email_subscribe" value="1" <?php if((bool)$customer['email_subscribe']) { ?> checked="checked" <?php } ?>/> <?php echo lang('account_newsletter_subscribe');?>
						</label>
					</td></tr>
			
				<tr><td>
						<div style="margin:30px 0px 10px; text-align:center;">
							<strong><?php echo lang('account_password_instructions');?></strong>
						</div>
					</td></tr>
			
				<tr><td>
						<label for="account_password"><?php echo lang('account_password');?></label>
						<?php echo form_password($password);?>
					</td></tr>

					<tr><td>
						<label for="account_confirm"><?php echo lang('account_confirm');?></label>
						<?php echo form_password($confirm);?>
					</td></tr>
			
				<tr><td><input id="submit" type="submit" value="<?php echo lang('form_submit');?>" class="btn btn-primary" /></td></tr>

			</fieldset>
		</form>
		</tbody>
	</table>
 </div>
</div>
	
<div class="span_new7 pull-right">
		<div  style="padding-top:10px;">
			<div class="span_new4">
				<h4><?php echo lang('address_manager');?></h4>
			</div>
            <?php if(!count($addresses) > 0):?>
			<div  style="text-align:right;width:80%;height:50px;">
            
				<input type="submit" class="button edit_address" rel="0" value="<?php echo lang('add_address');?>"/>
               
			</div> <?php endif;?>
		</div>
		<div >
			<div  id='address_list'>
			<?php if(count($addresses) > 0):?>
				<table class="table table-bordered table-striped">
			<?php
			$c = 1;
				foreach($addresses as $a):?>
					<tr id="address_<?php echo $a['id'];?>">
						<td>
							<?php
							$b	= $a['field_data'];  ?>
							
							
		 <table style="width:60%;">
    <tr> <td>
<?php echo $a['field_data']['firstname'].' '.$a['field_data']['lastname']?>  </td></tr>
    <tr> <td> <?php echo $a['field_data']['address1'];?>  </td></tr>
    <tr> <td> <?php echo $a['field_data']['city'];?>  </td></tr>
    <tr> <td> <?php echo $a['field_data']['phone'];?> </td></tr>
    <tr> <td> <?php echo $a['field_data']['email'];?> </td></tr>
  </table></div>
							
							
						</td>
						<td>
							<div class="row-fluid">
								<div class="span12">
									<div class="btn-group pull-right">
										<input type="submit"  class="button edit_address" rel="<?php echo $a['id'];?>" value="<?php echo lang('edit_shipping_address');?>" />
									</div>
								</div>
							</div>
							</td>
							<td>
							<div class="row-fluid">
								<div class="span12">
									<div class="pull-right" style="padding-top:10px;display:none;"><input type="radio" name="ship_chk" onclick="set_default(<?php echo $a['id'] ?>,'ship')" <?php if($customer['default_shipping_address']==$a['id']) echo 'checked="checked"'?>/> <?php echo lang('default_shipping');?>
									</div>
								</div>
							</div>
						</td>
					</tr>
				<?php endforeach;?>
				</table>
			<?php endif;?>
			</div>
			
	<div >
		<tr><td><h4><?php echo lang('order_history');?></h4></td></tr>
		
		<?php if($orders):
			echo $orders_pagination;
		?>
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th><?php echo lang('order_date');?></th>
					<th><?php echo lang('order_number');?></th>
					<th><?php echo lang('order_status');?></th>
				</tr>
			</thead>

			<tbody>
			<?php 
			
			foreach($orders as $order): ?>
				<tr>
					<td>
						<?php $d = format_date($order->ordered_on); 
				
						$d = explode(' ', $d);
						echo $d[0].' '.$d[1].', '.$d[3];
				
						?>
					</td>
					<td><?php echo $order->order_number; ?></td>
					<td><?php echo $order->status;?></td>
				</tr>
		
			<?php endforeach;?>
			</tbody>
		</table>
		<?php else: ?>
			<?php echo lang('no_order_history');?>
		<?php endif;?>
	</div>
 </div>
</div>
</div>
<div class="flythat" data-autoOpen="false" id="modal-text"> <a href="#close" class="close flythat-close">&times;</a>
              <div class="text-fly" id="product-container">
                
              </div>
            </div>
</div>
<div class="clear"></div>
</div>
</div>