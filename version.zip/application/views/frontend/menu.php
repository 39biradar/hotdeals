<script type="text/javascript">
function ChangeUrl(title, url,value) {
    if (typeof (history.pushState) != "undefined") {
		var min_length = 3; // min caracters to display the autocomplete
		if (value.length >= min_length) {
		var obj = { Title: title, Url: url };
        history.pushState(obj, obj.Title, obj.Url);
		window.location.href = url+'/'+value;
		}
    } else {
        alert("Browser does not support HTML5.");
    }
}
</script>
<script type="text/javascript">
function moveCaretToEnd(obj) {
    var value =  $(obj).val(); //store the value of the element
    if (isNotBlank(value)) {
        $(obj).focus().val("");
        $(obj).focus().val(value);
        $(obj).unbind();
     }
}
</script>
<div class="clear"></div>
</div>
<div class="headerBG" id="menu_div">
  <div id="headerMain">
    <div id="header">
      <div id="logo"> <a href="<?php echo base_url();?>"><img alt="sabzitime.com"  src="<?php echo base_url();?>assets/images/logo2.png"></a> </div>
      <div id="search">
    	<div class="button-search_icon"></div>
        
        <input type="text"  id="search_products"  onblur="if(this.value == '') {this.value = 'Search from over 500+ products';}"
 onfocus="if (this.value == 'Search from over 500+ products') {this.value = '';}"  onkeyup="ChangeUrl('Page1', '<?php echo site_url('cart/search_products');?>',this.value)" value="<?php echo $query; ?>" name="filter_name">
	</div>
      <div class="links"> <a href="<?php echo base_url();?>secure/login">My Account</a>
        <?php if($this->Customer_model->is_logged_in(false, false)):?>
        <a href="<?php echo site_url('secure/logout');?>"><?php echo lang('logout');?></a>
        <?php else: ?>
        <a href="<?php echo site_url('secure/login');?>"><?php echo lang('login');?></a>
        <?php endif; ?>
        <?php if($this->go_cart->total_items()>0) {?>
        <a href="<?php echo base_url();?>index.php/checkout">Checkout</a>
        <?php }?>
     <span id="viewkart"><a ><span >&nbsp;&nbsp; <span style="margin-left:5px;"><?php echo $this->go_cart->total_items();?> </span>  -&nbsp; &#8377; <?php echo $this->go_cart->total(); ?></span></a> </span>  
       <span id="show_items"> <a href="<?php echo base_url();?>cart/view_cart"> <span style="background:#000;"> <?php echo $this->go_cart->total_items();?></span>  -&nbsp; &#8377;<?php echo $this->go_cart->total(); ?></a></span> 
		
       </div>
  </div> 
    <div class="clear"></div>
	
  </div>
 
 
</div>
</div>
</header>
<!--Header Part End-->
<!--Error message-->
<?php if ($this->session->flashdata('message')):?>
<div class="alert alert-info"> <a class="close" data-dismiss="alert">×</a> <?php echo $this->session->flashdata('message');?> </div>
<?php endif;?>
<?php if ($this->session->flashdata('error')):?>
<div class="alert alert-error"> <a class="close" data-dismiss="alert">×</a> <?php echo $this->session->flashdata('error');?> </div>
<?php endif;?>
<?php if (!empty($error)):?>
<div class="alert alert-error"> <a class="close" data-dismiss="alert">×</a> <?php echo $error;?> </div>
<?php endif;?>
