<!--Footer Part Start-->

<footer>
  <div id="backTop" class="backTop" style="display: none;"><a class="backtotop" href="javascript:void(0)" title="Back to Top">Top</a></div>
  <div class="clear"></div>
  <div id="footerMain">
    <div id="footer">
      <div class="column">
        <ul>
          <li><a href="<?php echo base_url();?>index.php/cart/about_us">About Us</a></li>
          <li><a href="<?php echo base_url();?>index.php/cart/why_us">Why Us</a></li>
          <li><a href="<?php echo base_url();?>index.php/cart/contact_us">Contact Us</a></li>
          <li><a href="<?php echo base_url();?>index.php/cart/privacy_policy">Privacy Policy</a></li>
          <li><a href="<?php echo base_url();?>index.php/cart/terms_conditions">Terms &amp; Conditions</a></li>
        </ul>
      </div>
      <div class="column">
        <ul>
          <li><a href="#">Cash On Delivery.</a></li>
        </ul>
      </div>
      
      <div class="column">
        <div style="width: 99%;height: min-height: 92px;">
          <div style="float: left;" class="money_back">&nbsp;</div>
          <div style="float: none;color:#ffffff;">
            <p style="font-size: 12px;">100% Refund if the customer is not satisfied with the product at the time of delivery.</p>
          </div>
        </div>
      </div>
    </div>
    <div class="powered-main">
      <div id="powered">
        <div class="fl">Copyright &copy; 2014 Sabzitime. All Rights Reserved.</div>
        Developed by <a title="CURVEPIXELL" target="_blank" href="http://www.alcacel.com">Alcacel</a> </div>
    </div>
   
  </div>
</footer>
<!--Footer Part End-->
</div>
<!--Scroll back to top-->
<script>
$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() &gt; 100) {
				$('#backTop').fadeIn();
			} else {
				$('#backTop').fadeOut();
			}
		});
		});
jQuery('.backtotop').click(function(){
	jQuery('html, body').animate({scrollTop:0}, 'slow');
});

</script>


<!--end of Scroll back to top-->
</div>
</body></html>