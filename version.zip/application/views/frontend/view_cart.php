<div class="wrapper">
    <div id="notification"></div>
    <div id="container">
      <div id="content">
<?php if ($this->go_cart->total_items()==0):?>
    <div class="alert alert-info">
        <a class="close" data-dismiss="alert">×</a>
        <?php echo lang('empty_view_cart');?>
    </div>
<?php else: ?>
    
    <?php echo form_open('cart/update_cart', array('id'=>'update_cart_form'));?>

	<!--load checkout -->
	<?php $this->load->view('checkout/summary.php'); ?>
    
    
    <div class="row">
               
        <div  class="cart-info_actions">
                <input id="redirect_path" type="hidden" name="redirect" value=""/>
    
                <?php if(!$this->Customer_model->is_logged_in(false,false)): ?>
                    <input id="submit" type="submit" onclick="$('#redirect_path').val('checkout/login');" value="<?php echo lang('login');?>"/>
                    <input id="submit" type="submit" onclick="$('#redirect_path').val('checkout/register');" value="<?php echo lang('register_now');?>"/>
                <?php endif; ?>
                    <input id="submit" type="submit" value="<?php echo lang('form_update_cart');?>"/>
                    
            <?php if ($this->Customer_model->is_logged_in(false,false) || !$this->config->item('require_login')): ?>
                <input id="submit" type="submit" onclick="$('#redirect_path').val('checkout');" value="<?php echo lang('form_checkout');?>"/>
		 	
            <?php endif; ?>
            
        </div>
    </div>

</form>
<?php endif; ?>

 </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>