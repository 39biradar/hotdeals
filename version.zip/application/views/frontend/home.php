<div class="wrapper">
  <div id="notification"></div>
  <div id="container">
    <div class="home_menu">
    
   <?php $counter = 0; foreach ($result as $cat):?>
    
      <?php if($counter % 2 == 0) { ?>
      <div id='col1'>
      <div id='d1' class="column_category">
       <?php }else { ?>
        <div id='d2' class="column_category">
          <?php }?>
          <h7>
            <?=ucwords(strtolower($cat['name']))?>
          </h7>
          <ul>
            <?php if(isset($cat['sub_categories'])):?>
            <?php foreach($cat['sub_categories'] as $sub_category):?>
            <li><a href="<?php echo site_url($sub_category['slug']);?>">
              <?=$sub_category['name'];?>
              </a></li>
            <?php endforeach;?>
            <?php endif;?>
          </ul>
        </div>
      <?php if($counter % 2 == 1) { ?>
      </div>
       <?php } ?>
      
      <?php $counter++; endforeach;?>
    
      
    </div>
    <div class="clear"></div>
  </div>
</div>
