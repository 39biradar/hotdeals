<style>#search {display:none;}</style>

<div class="wrapper">
    <div id="notification"></div>
    <div id="container">

<div id="column-left" style="margin-top:100px;padding-left:10px;">
    <div class="box">
  <div class="box-heading"><span>Information</span></div>
  <div class="box-content">
  <div class="box-category">
    <ul>
            <li><a href="<?php echo base_url();?>index.php/cart/about_us">About Us</a></li>
            <li><a href="<?php echo base_url();?>index.php/cart/contact_us">Contact Us</a></li>
            <li><a href="<?php echo base_url();?>index.php/cart/privacy_policy">Privacy Policy</a></li>
            <li><a href="<?php echo base_url();?>index.php/cart/terms_conditions">Terms &amp; Conditions</a></li>
    
    </ul>
    </div>
  </div>
</div>
  </div>
 
<div id="content" style="padding-top:100px;padding-right:20px;">		 
  
  <h1><span>Contact Us </span></h1>
  <p>For all orders and enquiries call  on 9953495050 or email us at <a  href="mailto:care@sabzitime.com?subject=Sabzitime Customer Support">care@sabzitime.com</a> .</p>
  
  </div>
<div class="clear"></div>


</div>
      <div class="clear"></div>
    </div>
  </div>