<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> <?php  echo (!empty($page_title)) ? $page_title .' - ' : ''; echo 'sabzitime.com'; ?> </title>
<meta name="Keywords" content="<?php echo (!empty($seo_title)) ? $seo_title  : '';  ?> ">
<meta name="Description" content="<?php echo (!empty($meta)) ? $meta .' - ' : ''; echo "sabzitime.com"; ?>">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="True" name="HandheldFriendly">
<meta content="320" name="MobileOptimized">
<meta content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" name="viewport">
<link href="images/favicon.ico" type="image/x-icon" rel="shortcut icon">
<!-- Comment following two lines to use Color Changer -->
<link media="screen" href="<?php echo base_url();?>assets/css/stylesheet.css" type="text/css" rel="stylesheet">
<link id="color_scheme" href="<?php echo base_url();?>assets/css/color-schemes/black.css" type="text/css" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Carme">
<link media="screen" href="<?php echo base_url();?>assets/css/carousel.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/elastislide.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/transition.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/admin/css/jquery-ui.css" type="text/css" rel="stylesheet">
<!--for toast notifications-->
<link href="<?php echo base_url();?>assets/css/toastr.min.css" type="text/css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/js/jquery-1.8.2.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.cookie.js"></script>
<script src="<?php echo base_url();?>assets/js/common.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.cycle.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.jcarousel.min.js"></script>
<script src="<?php echo base_url();?>assets/js/html5.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.tooltipster.min.js"></script>
<script src="<?php echo base_url();?>assets/js/modernizr.custom.17475.js"></script>
<script src="<?php echo base_url();?>assets/js/squard.js"></script>
<script src="<?php echo base_url();?>assets/js/equal_heights.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<!--for toast notifications-->
<script src="<?php echo base_url();?>assets/js/toastr.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.flythat.js"></script>

<!--custom radio in select delivery time-->
<script src="<?php echo base_url();?>assets/js/custom.min.js?v=1.0.2"></script>
<link href="<?php echo base_url();?>assets/css/skins/square/green.css" rel="stylesheet">
<script src="<?php echo base_url();?>assets/js/icheck.js"></script>

</head>

<body >
<div class="mainWrapper">
  <!--Header Part Start-->
  <header>
    <div class="headerTopBg">
      <div class="headerTop">	
		

