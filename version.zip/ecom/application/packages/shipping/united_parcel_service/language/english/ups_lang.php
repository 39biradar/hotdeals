<?php

$lang['account']	= 'Account Name';
$lang['fee']	= 'Handling Fee';
$lang['services']	= 'Services to Allow';
$lang['key']	= 'Access Key';
