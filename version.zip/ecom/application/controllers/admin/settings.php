<?php

class Settings extends Admin_Controller {
    
    function __construct()
    {
        parent::__construct();

        $this->auth->check_access('Admin', true);
        $this->load->model('Settings_model');
        $this->load->model('Messages_model');
        $this->lang->load('settings');
        $this->load->helper('inflector');
    }
    
    function index()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');


        $this->form_validation->set_rules('company_name', 'lang:company_name', 'required');
        $this->form_validation->set_rules('country_id', 'lang:country');
        $this->form_validation->set_rules('address1', 'lang:address');
        $this->form_validation->set_rules('address2', 'lang:address');
        $this->form_validation->set_rules('zone_id', 'lang:state');
        $this->form_validation->set_rules('zip', 'lang:zip');


        $data = $this->Settings_model->get_settings('gocart');
        
     
        $data['countries_menu'] = $this->Location_model->get_countries_menu();
        if(!empty($data['country_id']))
        {
            $data['zones_menu'] = $this->Location_model->get_zones_menu($data['country_id']);
        }
        else
        {
            $data['zones_menu'] = $this->Location_model->get_zones_menu(array_shift(array_keys($data['countries_menu'])));
        }

        $data['page_title'] = lang('common_gocart_configuration');

        if ($this->form_validation->run() == FALSE)
        {
            $data['error'] = validation_errors();
            $this->view($this->config->item('admin_folder').'/settings', $data);
        }
        else
        {
            $this->session->set_flashdata('message', lang('config_updated_message'));

            $save = $this->input->post();
            //fix boolean values
            $this->Settings_model->save_settings('gocart', $save);

            redirect(config_item('admin_folder').'/settings');
        }
        
    }
	
	function form($id = false)
	{	
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('
<div class="error">', '</div>
');
		
		$data['page_title']		= lang('locality_form');
		
		//default values are empty if the customer is new
		$data['id']		= '';
		$data['locality_name']	= '';
		
		
		if ($id)
		{	
			$locality			= $this->Settings_model->get_locality($id);
			//set values to db values
			$data['id']			= $locality->id;
			$data['locality_name']	= $locality->locality_name;
		}
		
		$this->form_validation->set_rules('locality_name', 'lang:locality_name', 'trim|required');				
		if ($this->form_validation->run() == FALSE)
		{
			$this->view($this->config->item('admin_folder').'/locality_form', $data);
		}
		else
		{
			$save['id']		= $id;
			$save['locality_name']	= $this->input->post('locality_name');										
			$this->Settings_model->save_locality($save);
			
			$this->session->set_flashdata('message', lang('message_user_saved'));
			
			//go back to the customer list
			redirect($this->config->item('admin_folder').'/settings/deliveryareas');
		}
	}
	
	function deliveryareas()
	{
		$data['page_title']	= lang('locality_form');
		$data['delivery_area']		= $this->Settings_model->get_all_delivery_areas();

		$this->view($this->config->item('admin_folder').'/delivery_areas', $data);
	}
	
	function delete($id)
	{
		//delete the user
		$this->Settings_model->delete_delivery_area($id);
		redirect($this->config->item('admin_folder').'/settings/deliveryareas');
	}
	
	
	function shipping_charge_form($id = false)
	{	
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		
		$data['page_title']		= lang('locality_form');
		
		//default values are empty if the customer is new
		$data['id']		= '';
		$data['order_amount']	= '';
		$data['shipping_charge']	= '';
		
		
		if ($id)
		{	
			$shipping_charges			= $this->Settings_model->get_shipping_charges($id);
			//set values to db values
			$data['id']			= $shipping_charges->id;
			$data['order_amount']	= $shipping_charges->order_amount;
			$data['shipping_charge']	= $shipping_charges->shipping_charge;
			$this->view($this->config->item('admin_folder').'/shipping_charge_form', $data);
		}
		else
		{
		$this->view($this->config->item('admin_folder').'/shipping_charge_form', $data);
		}
		
		
	}
	
	
	function save_shipping_charge($id = false)
	{	
		
		$data['page_title']		= lang('locality_form');
		
			$save['id']		= $id;			
			$order_amount   = explode("-", $this->input->post('order_amount'));
			$save['frm_order_amount']	= $order_amount[0];
			$save['to_order_amount']	= $order_amount[1];	
			$save['shipping_charge']	= $this->input->post('shipping_charge');										
			$this->Settings_model->save_shipping_charge($save);
			
			$this->session->set_flashdata('message', lang('message_user_saved'));
			
			//go back to the customer list
			redirect($this->config->item('admin_folder').'/settings/shipping_charges');
		
		
	}
	
	function delete_shipping_charge($id)
	{
		//delete the user
		$this->Settings_model->delete_shipping_charge($id);
		redirect($this->config->item('admin_folder').'/settings/shipping_charges');
	}
	
	function shipping_charges()
	{
		$data['page_title']	= lang('locality_form');
		$data['shipping_charges']		= $this->Settings_model->get_all_shipping_charge();
		$this->view($this->config->item('admin_folder').'/shipping_charges', $data);
	}

}